function autocomplet() {
	var min_length = 0; // nombre de caractère avant lancement recherch
	var keyword = $('#libcate').val();  // #nomclient fait référence au champ de recherche puis lancement de la recherche

		// Pas besoin d'explication ici tu fais copier coller

	if (keyword.length >= min_length) {
		$.ajax({
			url: 'include/autocompletion_categorie.php',
			type: 'POST',
			data: {keyword:keyword},
			success:function(data){
				$('#list_cate').show();
				$('#list_cate').html(data);
			}
		});
	} else {
		$('#list_cate').hide();
	}
}

// Lors du choix dans la liste
function set_item(item,id) {
	// change input value
	//  change les valeurs des input :)
	$('#libcate').val(item);
	$('#idcate').val(id);
	// cache la liste une fois validé
	$('#list_cate').hide();
}

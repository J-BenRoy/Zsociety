function autocomplettypeprod() {
	var min_length = 0; // nombre de caractère avant lancement recherch
	var keyword = $('#libtypeprod').val();  // #nomclient fait référence au champ de recherche puis lancement de la recherche

		// Pas besoin d'explication ici tu fais copier coller

	if (keyword.length >= min_length) {
		$.ajax({
			url: 'include/autocompletion_typeprod.php',
			type: 'POST',
			data: {keyword:keyword},
			success:function(data){
				$('#list_typeprod').show();
				$('#list_typeprod').html(data);
			}
		});
	} else {
		$('#list_typeprod').hide();
	}
}

// Lors du choix dans la liste
function set_item(item,id) {
	// change input value
	//  change les valeurs des input :)
	$('#libtypeprod').val(item);
	$('#idtypeprod').val(id);
	// cache la liste une fois validé
	$('#list_typeprod').hide();
}

$("#send").click(function(){
		
		var date = $("#datepicker").val();
		var time = $("#heure").val();
		var typerep = $("#typerepas").val();
		var idcli = $("#idclient").val();
		var produit = [];
        $('#produit input:checked').each(function(){
            produit.push($(this).val());
});
		alert(produit);
		//lib et nom en violet represente les variables juste en haut et en blanc correspond au $_POST[''] que l'on va récupérer dans le traitement
	$.post("traitement/traitement_passage.php", {date:date, time:time, typerep:typerep, idcli:idcli, produit:produit}, function(data){
		console.log(data);
      })
	});

$("#valider_passage").click(function(){
    $.ajax({
       url : 'traitement/traitement_passage_client.php',
       type :'POST',
       data : 'date=' + $(#datepicker).attr() + '&TypeRepas=' + $(#typerepas) + '&'
    });
});

<?php
include 'include/haut.inc.php';
?>
<html>
  <body>
    <form method="post" action="traitement/traitement_client.php">
      <input type="text" name="nomclient"><br>
      <input type="text" name="mdpclient"><br>
      <input type="submit" value="valider">
    </form>
  </body>
</html>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio - Dark Admin de la mort qui tue</title>

    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/local.css" />
    
    <!-- link Datepicker-->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">

    <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
    
    <!-- Script Datepicker-->
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <style>
	   .demo {
	   	border:1px solid #C0C0C0;
	   	border-collapse:collapse;
	   	padding:5px;
	   }
	   .demo th {
	   	border:1px solid #C0C0C0;
	   	padding:5px;
	   	background:#1E90FF;
	   }
	   .demo td {
	   	border:1px solid #C0C0C0;
	   	padding:5px;
	   }
    </style>
</head>
<body>

    <div id="wrapper">

        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Back to Admin</a>
            </div>
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <?php
                include'include/header.inc.php';
                ?>
                <ul class="nav navbar-nav navbar-right navbar-user">
                    <li class="dropdown user-dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> Steve Miller<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="#"><i class="fa fa-user"></i> Profile</a></li>
                            <li><a href="#"><i class="fa fa-gear"></i> Settings</a></li>
                            <li class="divider"></li>
                            <li><a href="#"><i class="fa fa-power-off"></i> Log Out</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h3 class="panel-title"><i class="glyphicon glyphicon-search"></i> Recherche</h3>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="col-md-2">
                                    <label>Date</label>
                                    <input type="text" id="datepicker" class="form-control input-sm"></p>
                                    <label>Nom</label>
                                    <input id="textinput" name="textinput" class="form-control input-sm" type="text">
                                    <label>Prénom</label>
                                    <input id="textinput" name="textinput" class="form-control input-sm" type="text">
                                <button type="button" class="btn btn-primary btn-sm glyphicon glyphicon-search" id="search"> Rechercher</button>
                                <a class="btn btn-primary btn-sm glyphicon glyphicon-refresh" href="client.php" role="button" id="reset"> Reinitialiser</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row" id="searchcli">
                <div class="col-md-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h3 class="panel-title"><i class="glyphicon glyphicon-user"></i> Client</h3>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="col-md-2">
                                    <label>Nom</label>
                                    <input id="textinput" name="textinput" style="color:black;" class="form-control input-sm" type="text" value="Saké">
                                    <label>Prénom</label>
                                    <input id="textinput" name="textinput" style="color:black;" class="form-control input-sm" type="text" value="Frodon">
                                    <label>Type de client</label>
                                    <input id="textinput" name="textinput" style="color:black;" class="form-control input-sm" type="text" value="Etudiant">
                                    <label>Solde</label>
                                    <input id="textinput" name="textinput" style="color:black;" class="form-control input-sm" type="text" value="25€">
                                    <label>Fidelisé</label>
                                    <input type="checkbox" value="checked">
                                    <div class="form-group">
                                        <table class="demo">
                                        <thead>
                                            <tr>
                                                <th>Horaires</th>
                                                <th>Lundi</th>
                                                <th>Mardi</th>
                                                <th>Mercedi</th>
                                                <th>Jeudi</th>
                                                <th>Vendredi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Midi</td>
                                                <td><input type="checkbox"></td>
                                                <td><input type="checkbox"></td>
                                                <td><input type="checkbox"></td>
                                                <td><input type="checkbox"></td>
                                                <td><input type="checkbox"></td>
                                            </tr>
                                            <tr>
                                                <td>Soir</td>
                                                <td><input type="checkbox"></td>
                                                <td><input type="checkbox"></td>
                                                <td><input type="checkbox"></td>
                                                <td><input type="checkbox"></td>
                                                <td><input type="checkbox"></td>
                                            </tr>
                                        <tbody>
                                        </table>
                                        <button type="button" class="btn btn-primary btn-sm glyphicon glyphicon-th-list" id="historique"> Historique</button>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div class="form-group">
                                <div class="col-md-2">
                                    <img src="img/frodon.jpeg" style="max-height:180px; max-width=80px;">
                                </div
                                </div>
                            </div>
                            <div class="col-md-2 col-md-offset-1">
                            </div>
                            <div class="form-group">
                                <div class="col-md-2" id="histo">
                                    <table class="demo">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Heure</th>
                                                <th>Prix</th>
                                                <th>Détail</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>21/11/2016</td>
                                                <td>12:30</td>
                                                <td>5€20</td>
                                                <td><p><a href="#" id="boutoninformation" class="lienstylebouton">Lien</a></p></td>
                                            </tr>
                                            <tr>
                                                <td>21/11/2016</td>
                                                <td>12:30</td>
                                                <td>5€20</td>
                                                <td><p><a href="#" id="boutoninformation" class="lienstylebouton">Lien</a></p></td>
                                            </tr>
                                        <tbody>
                                    </table>
                                </div>
                            </div>
                               <div id="popupinformation" title="Détails">
                                   <div class="form-group">
                                        <div class="col-md-5" style="color:black;">
                                            <label>Date</label>
                                            <input id="textinput" name="textinput" style="color:black;" class="form-control input-md" type="text" value="15/09/2016" disabled="disabled">
                                            <label>Heure</label>
                                            <input id="textinput" name="textinput" style="color:black;" class="form-control input-md" type="text" value="12:30" disabled="disabled">
                                            <label>Prix</label>
                                            <input id="textinput" name="textinput" style="color:black;" class="form-control input-md" type="text" value="5€20" disabled="disabled">
                                        </div>
                                    </div>
                               </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script type="text/javascript">
        jQuery(function ($) {

            $( "#datepicker" ).datepicker();
            $("#searchcli").hide();
            $("#reset").hide();
            $("#histo").hide();
            $( "#search" ).click(function() {
                $("#searchcli").fadeIn();
                $("#reset").fadeIn();
                $("#search").hide();
});
            $( "#historique" ).click(function() {
                $("#histo").fadeIn();
});
            // définition de la boîte de dialogue

            // la méthode jQuery dialog() permet de transformer un div en boîte de dialogue et de définir ses boutons
        
            $( "#popupinformation" ).dialog({
        
                autoOpen: false,
        
                width: 400,
        
                buttons: [
        
                    {
        
                        text: "Fermer",
        
                        click: function() {
        
                            $( this ).dialog( "close" );
        
                        }
        
                    }
        
                ]
        
            });
        
            // comportement du bouton devant ouvrir la boîte de dialogue
        
            $( "#boutoninformation" ).click(function( event ) {
        
                // cette ligne est très importante pour empêcher les liens ou les boutons de rediriger
        
                // vers une autre page avant que l'usager ait cliqué dans le popup
        
                event.preventDefault();
        
                // affichage du popup
        
                $( "#popupinformation" ).dialog( "open" );
        
            });
        });
    </script>
</body>
</html>

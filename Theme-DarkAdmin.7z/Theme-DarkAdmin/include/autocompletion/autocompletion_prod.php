<?php
//Auto completion des produits
include'../haut.inc.php';

$keyword = '%'.$_POST['keyword'].'%';  // recupere la lettre saisie dans le champ texte en provenance de JS

// Requête de selection

$sql = "SELECT * FROM produits WHERE valide='1'";
if(is_numeric($keyword)){
	$sql =$sql." AND libproduits = '$keyword'";
}
else{
	$sql =$sql." AND libproduits LIKE (:keyword) ORDER BY libproduits";
}
$query = $conn->prepare($sql);
$query->bindParam(':keyword', $keyword, PDO::PARAM_STR);
$query->execute();
$list = $query->fetchAll();
foreach ($list as $rs) {
	//  Juste l'affichage de la liste, tu as vu comment ca marche hier
	$libprod = str_replace($_POST['keyword'],$_POST['keyword'],' '.$rs['libproduits'].'<br><br>');
	// Selection
    echo '<li onclick="set_item(\''.str_replace("'", "\'",$rs['libproduits']).'\',\''.str_replace("'", "\'", $rs['idproduits']).'\')">'.$libprod.'</li>';
}
?>

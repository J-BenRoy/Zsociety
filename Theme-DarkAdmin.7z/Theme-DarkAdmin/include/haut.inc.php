<?php
include'class/class_cat.inc.php';
include'class/class_tarif.inc.php';
include'class/class_typeclients.inc.php';
include'class/class_produit.inc.php';
include'class/class_typerepa.inc.php';
include'bdd.inc.php';

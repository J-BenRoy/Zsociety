<?php
    class clients{
        private $idclient;
        private $nomclient;
        private $prenomclient;
        private $photoclient;
        private $codebarre;
        private $lundim;
        private $lundis;
        private $mardim;
        private $mardis;
        private $mercredim;
        private $mercredis;
        private $jeudim;
        private $jeudis;
        private $vendredim;
        private $vendredis;
        private $valide;
        private $mdp;

        public function clients($idc,$nomcli,$precli,$photocli,$cb,$lm,$ls,$mm,$ms,$merm,$mers,$jm,$js,$vm,$vs,$val,$mdpcli)
        {
            $this -> idclient = $idc;
            $this -> nomclient = $nomcli;
            $this -> prenomclient = $precli;
            $this -> photoclient = $photocli;
            $this -> codebarre = $cb;
            $this -> lundim = $lm;
            $this -> lundis = $ls;
            $this -> mardim = $mm;
            $this -> mardis = $ms;
            $this -> mercredim = $merm;
            $this -> mercredis = $mers;
            $this -> jeudim = $jm;
            $this -> jeudis = $js;
            $this -> vendredim = $vm;
            $this -> vendredis = $vs;
            $this -> valide = $val;
            $this -> mdp = $mdpcli;
        }

        public function get_idclient()
        {
            return $this -> idclients;
        }

        public function get_nomclient()
        {
            return $this -> nomclient;
        }

        public function get_prenomclient()
        {
            return $this -> prenomclient;
        }

        public function get_motdepasse()
        {
          return $this -> mdp;
        }

        public function get_photo()
        {
            return $this -> photoclient;
        }

        public function get_codebarre()
        {
            return $this -> codebarre;
        }

        public function get_lundim()
        {
            return $this -> lundim;
        }

        public function get_lundis()
        {
            return $this -> lundis;
        }

        public function get_mardim()
        {
            return $this -> mardim;
        }

        public function get_mardis()
        {
            return $this -> mardis;
        }

        public function get_mercredim()
        {
            return $this -> mercredim;
        }

        public function get_mercredis()
        {
            return $this -> mercredis;
        }

        public function get_jeudim()
        {
            return $this -> jeudim;
        }

        public function get_jeudis()
        {
          return $this -> jeudis;
        }

        public function get_vendredim()
        {
          return $this -> vendredim;
        }

        public function get_vendredis()
        {
          return $this -> vendredis;
        }

        public function get_valide()
        {
          return $this -> valide;
        }

        public function set_lundim($lm)
        {
          $this -> lundim = $lm;
        }

        public function set_lundi($ls)
        {
          $this -> lundis = $ls;
        }

        public function set_mardim($mm)
        {
          $this -> mardim = $mm;
        }

        public function set_mardis($ms)
        {
          $this -> mardis = $ms;
        }

        public function set_mercredim($merm)
        {
          $this -> mercredim = $merm;
        }

        public function set_mercredis($mers)
        {
          $this -> mercredis = $mers;
        }

        public function set_jeudim($jm)
        {
          $this -> jeudim = $jm;
        }

        public function set_jeudis($js)
        {
          $this -> jeudis = $js;
        }

        public function set_vendredim($vm)
        {
          $this -> vendredim = $vm;
        }

        public function set_vendredis($vs)
        {
          $this -> vendredis = $vs;
        }

        public function set_nomclient($nomcli)
        {
          $this -> nomclient = $nomcli;
        }

        public function set_prenomclient($precli)
        {
          $this -> prenomclient = $precli;
        }

        public function set_photo($ph)
        {
          $this -> photoclient = $ph;
        }

        public function set_codebarre($cb)
        {
          $this -> codebarre = $cb;
        }

        public function set_valide($v)
        {
          $this -> valide = $v;
        }

        public function afficher_client($idcli,$conn)
        {
        	$SQL = "SELECT * FROM clients WHERE valide='1' AND idclients='$idcli'";
          $resa = $conn->query($SQL);
        	$resa->setFetchMode ( PDO::FETCH_OBJ );
        	return $resa;
        }

        public function select_client($nomcli,$mdpcli,$conn)
        {
          $SQL = "SELECT * FROM clients WHERE valide='1' AND nomclient='$nomcli' AND motdepasse='$mdpcli'";
          $resa = $conn->query($SQL);
          $resa->setFetchMode ( PDO::FETCH_OBJ );
        	return $resa;
        }
    }
?>

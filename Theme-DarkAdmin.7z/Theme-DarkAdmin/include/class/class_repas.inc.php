<?php
  /**
   *
   */
  class repas
  {
    private $idrepas;
    private $daterepas;
    private $heurerepas;
    private $prix;
    private $note;
    private $valide;

    public function repas($idrep,$daterep,$heurerep,$prixrep,$noterep,$val)
    {
      $this -> idrepas = $idrep;
      $this -> daterepas = $daterep;
      $this -> heurerepas = $heurerep;
      $this -> prix = $prixrep;
      $this -> note = $noterep;
      $this -> valide = $val;
    }

    public function get_idrepas()
    {
      return $this -> idrepas;
    }

    public function get_daterepas()
    {
      return $this -> daterepas;
    }

    public function get_heurerepas()
    {
      return $this -> heurerepas;
    }

    public function get_prix()
    {
      return $this -> prix;
    }

    public function get_note()
    {
      return $this -> note;
    }

    public function get_valide()
    {
      return $this -> valide;
    }

    public function set_prix($prixrepas)
    {
      $this -> prix = $prixrepas;
    }

    public function set_note($noterepas)
    {
      $this -> note = $noterepas;
    }

    public function set_valide($validerepas)
    {
      $this -> $valide = $validerepas;
    }

    public function select_repas($conn,$idc)
    {
        $resa = $conn->query("SELECT * FROM repas,clients
                              WHERE clients.idclients = repas.idclients;
                              AND repas.valide='1'
                              AND repas.idclients= '$idc'");
		$resa->setFetchMode ( PDO::FETCH_OBJ );
        return $resa;
    }
	public function repas_client($idcli,$conn)
    {
      $SQL = "SELECT * FROM repas WHERE valide='1' AND idclients='$idcli'";
      $resa = $conn->query($SQL);
      $resa->setFetchMode ( PDO::FETCH_OBJ );
      return $resa;
    }

    public function update_note($noterepas,$idrepas,$conn)
    {
      $SQL="UPDATE repas SET note='$noterepas' WHERE idrepas= '$idrepas'";
  		$resultat = $conn -> query ($SQL);
      $this->note = $noterepas;
    }
	
	 public function nouveau_repas($idrep,$daterep,$heurerep,$prixrep,$idcli,$typerepas,$note,$valide,$conn)
	 {
			$SQL ="INSERT INTO repas VALUES('$idrepas','$daterep','$heurerep','$prixrep','$idcli','$typerepas','$note','$valide')";
		 	$resultat = $conn->query($SQL);
	 }
  }

 ?>

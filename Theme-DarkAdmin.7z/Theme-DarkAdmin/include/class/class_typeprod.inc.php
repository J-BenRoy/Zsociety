<?php
  class typeproduit
  {
    private $idtypeprod;
    private $libtypeprod;
    private $valide;
    public function typeproduit($idtp,$libtp,$val)
    {
      $this -> idtypeprod = $idtp;
      $this -> libtypeprod = $libtp;
      $this -> valide = $val;
    }

    public function get_idtp()
    {
      return $this -> idtypeprod;
    }

    public function get_libtp()
    {
      return $this -> libtypeprod;
    }

    public function get_valide()
    {
      return $this -> valide;
    }

    public function set_libtp($ltp)
    {
      $this -> libtypeprod = $ltp;
    }

    public function set_valide($val)
    {
      $this -> valide = $val;
    }

    public function afficher_typeprod($conn)
    {
      $SQL = "SELECT * FROM typeproduit WHERE valide='1'";
      $resa = $conn->query($SQL);
      $resa->setFetchMode ( PDO::FETCH_OBJ );
      return $resa;
    }
  }

 ?>

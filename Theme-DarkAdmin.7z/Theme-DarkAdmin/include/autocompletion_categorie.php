<?php
//Auto completion des categories
include'haut.inc.php';

$keyword = '%'.$_POST['keyword'].'%';  // recupere la lettre saisie dans le champ texte en provenance de JS

// Requête de selection

$sql = "SELECT * FROM categorie WHERE valide='1'";
if(is_numeric($keyword)){
	$sql =$sql." AND libcat = '$keyword'";
}
else{
	$sql =$sql." AND libcat LIKE (:keyword) ORDER BY libcat";
}
$query = $conn->prepare($sql);
$query->bindParam(':keyword', $keyword, PDO::PARAM_STR);
$query->execute();
$list = $query->fetchAll();
foreach ($list as $rs) {
	//  Juste l'affichage de la liste, tu as vu comment ca marche hier
	$libcate = str_replace($_POST['keyword'],$_POST['keyword'],' '.$rs['libcat'].'<br><br>');
	// S�lection
    echo '<li onclick="set_item(\''.str_replace("'", "\'",$rs['libcat']).'\',\''.str_replace("'", "\'", $rs['idcat']).'\')">'.$libcate.'</li>';
}
?>

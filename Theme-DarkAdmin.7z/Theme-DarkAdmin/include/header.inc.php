<ul id="active" class="nav navbar-nav side-nav">
    <li class="selected"><a href="index.php"><i class="fa fa-barcode"></i> Passage</a></li>
    <li><a href="client.php"><i class="glyphicon glyphicon-user"></i> Client</a></li>
    <li><a href="categorie.php"><i class="fa fa-globe"></i> categorie</a></li>
    <li><a href="produit.php"><i class="fa fa-list-ol"></i> Produits</a></li>
    <li><a href="tarif.php"><i class="fa fa-font"></i> Tarifs</a></li>
    <li><a href="timeline.html"><i class="fa fa-font"></i> Timeline</a></li>
    <li><a href="forms.html"><i class="fa fa-list-ol"></i> Forms</a></li>
    <li><a href="typography.html"><i class="fa fa-font"></i> Typography</a></li>
    <li><a href="bootstrap-elements.html"><i class="fa fa-list-ul"></i> Bootstrap Elements</a></li>
</ul>
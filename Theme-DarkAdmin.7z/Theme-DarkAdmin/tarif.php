<?php
include 'include/haut.inc.php';
$letarif = new produits ( '', '', '' );
?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Dark Admin</title>

    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/local.css" />

    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript"src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script type="text/javascript" src="js/list_client_passage.js"></script>
    <script type="text/javascript" src="js/verif_eleve_ajax.js"></script>
    <script type="text/javascript" src="js/produit.js"></script>
      <style>

        div {
            padding-bottom:20px;
        }

    </style>
</head>
<body>

    <div id="wrapper">
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Safe &amp; Self</a>
            </div>
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <?php
                    include'include/header.inc.php';
                    ?>
                </ul>
            </div>
        </nav>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <h3 class="panel-title"><i class="glyphicon glyphicon-search"></i>Selectionner un produit</h3>
                    </div>
                    <div class="panel-body">
                        <div class="form-group">
                            <div class="col-md-2">
                                <FORM method="post" style="color:black;">
                                  <input type="text" id="libproduit" onkeyup="autocomplet()">
                                  <input type="hidden" id="idproduit" name="idproduit"onkeyup="autocomplet()">
                                  <ul id="list_produit"></ul>
                                  <input type="submit" name="modiftarif" id="selecttarif" value="Valider">
	                           </FORM>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            if (isset ( $_POST ['modiftarif'] ))
            {
                  $idp = $_POST ['idproduit'];
                  $tabtarif = new tarif ( '', '', '', '' );
                  ?>
                  <div class="col-md-6">
                    <div class="panel panel-primary" id="showtarif">
                      <div class="panel-heading">
                          <h3 class="panel-title"><i class="glyphicon glyphicon-search"></i>Visualiser les tarifs</h3>
                      </div>
                      <div class="panel-body">
                        <div class="form-group">
                          <div class="col-md-2">
                            <form method="post" action="traitement/traitement_modifier_tarif.php">
                              <input type="hidden" name="idprod" value="<?php echo $idp ?>">
                                <table>
                                    <tr>
                                      <th>Lib Tarif</th>
                                      <th>TN</th>
                                      <th>TF</th>
                                    </tr>
                                    <?php
                                    // affichage et modification des tarifs
                                    $resa = $tabtarif->select_tarif ( $conn, $idp );
                                    while ( $tab = $resa->fetch () )
                                    {
                                        $tn = "tn".$tab->idcat.$tab->idproduits;
                                        $tf = "tf".$tab->idcat.$tab->idproduits;
                                        ?>
                                        <tr>
                                            <td>
                                                <?php echo $tab->libcat; ?>
                                            </td>
                                            <td style="color:black;">
                                                <input type="text" name="<?php echo $tn; ?>" value="<?php echo $tab->tarifN; ?>">
                                            </td>
                                            <td style="color:black;">
                                                <input type="text" name="<?php echo $tf; ?>" value="<?php echo $tab->tarifF; ?>">
                                            </td>
                                        </tr>

                                        <?php
                                    }
                                        ?>
                                    </table>
                                    <input type="submit" name="modifcate" value="Modifier">
                                </form>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
        <?php
        }?>
        </div>
    </div>
  </body>
</html>

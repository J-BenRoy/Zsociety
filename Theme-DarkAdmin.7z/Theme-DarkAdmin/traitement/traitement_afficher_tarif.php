<?php
include '../include/haut.inc.php';
$letarif = new produits ( '', '', '' );
?>

<?php
if (isset ( $_POST ['prod'] ))
{
	$idp = $_POST ['prod'];
	$tabtarif = new tarif ( '', '', '', '' );
	?>
	<form method="post" action="traitement_modifier_tarif.php">
        <input type="hidden" name="idprod" value="<?php echo $idp ?>">
		<table>
		<tr>
			<th>Lib Tarif</th>
			<th>TN</th>
			<th>TF</th>
		</tr>
			<?php
	$resa = $tabtarif->select_tarif ( $conn, $idp );
	while ( $tab = $resa->fetch () ) {
		//Chaque tarif à un ID categorie et un ID produit qui lui est attribue donc on fait une concatenation des deux afin de pouvoir les differencier
		$tn = "tn".$tab->idcat.$tab->idproduits;
		$tf = "tf".$tab->idcat.$tab->idproduits;

        echo $tn;
        	?>
               <tr>
                   <td>
         				<?php echo $tab->libcat; ?>
         		   </td>
                   <td>
                   		<input type="text" name="<?php echo $tn; ?>" value="<?php echo $tab->tarifN; ?>">
                   </td>
					<td>
						<input type="text" name="<?php echo $tf; ?>" value="<?php echo $tab->tarifF; ?>">
					</td>
			  </tr>

	<?php
	}
	?>

		</table>

		<input type="submit" name="modifcate" value="Modifier">
        </form>
        <?php
}
?>

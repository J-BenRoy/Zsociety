<?php
include'../include/haut.inc.php';
$idcat= $_POST['idcate'];
$lacat = new categorie('','','');
$lacat->delete_categorie($idcat,$conn);
Header("Location:../categorie.php");
?>

<?php
    class clients{
        private $idclient;
        private $nomclient;
        private $prenomclient;
        private $photoclient;
        private $codebarre;
        private $lundim;
        private $lundis;
        private $mardim;
        private $mardis;
        private $mercredim;
        private $mercredis;
        private $jeudim;
        private $jeudis;
        private $vendredim;
        private $vendredis;
        private $valide;
        
        public function clients($idc,$nomcli,$precli,$photocli,$cb,$lm,$ls,$mm,$ms,$merm,$mers,$jm,$js,$vm,$vs,$val)
        {
            $this -> idclient = $idc;
            $this -> nomclient = $nomcli;
            $this -> prenomclient = $precli;
            $this -> photoclient = $photocli;
            $this -> codebarre = $cb;
            $this -> lundim = $lm;
            $this -> lundis = $ls;
            $this -> mardim = $mm;
            $this -> mardis = $ms;
            $this -> mercredim = $merm;
            $this -> mercredis = $mers;
            $this -> jeudim = $jm;
            $this -> jeudis = $js;
            $this -> vendredim = $vm;
            $this -> vendredis = $vs;
            $this -> valide = $val;
        }
        
        public function get_idclient()
        {
            return $this -> idclients;
        }
        
        public function get_nomclient()
        {
            return $this -> nomclient;
        }
        
        public function get_prenomclient()
        {
            return $this -> prenomclient;
        }
        
        public function get_photo()
        {
            return $this -> photoclient;
        }
        
        public function get_codebarre()
        {
            return $this -> codebarre;
        }
        
        public function get_lundim()
        {
            return $this -> lundim;
        }
        
        public function get_lundis()
        {
            return $this -> lundis;
        }
        
        public function get_mardim()
        {
            return $this -> mardim;
        }
        
        public function get_mardis()
        {
            return $this -> mardis;
        }
        
        public function get_mercredim()
        {
            return $this -> mercredim;
        }
        
        public function get_mercredis()
        {
            return $this -> mercredis;
        }
    }
?>
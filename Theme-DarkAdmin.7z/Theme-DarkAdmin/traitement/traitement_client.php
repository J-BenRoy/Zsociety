<?php
include'../include/haut.inc.php';
$lecli = new clients('','','','','','','','','','','','','','','','','');
//Vérifie et redirige vers Administrateur.php
if(isset($_POST['nomclient'])&&isset($_POST['mdpclient']))
{
      $req = $conn->prepare("SELECT * FROM clients WHERE nomclients = ? AND motdepasse = ?");
      $req->execute(array($_POST['nomclient'], $_POST['mdpclient']));
      $data = $req->fetch();
 if($data)
 {
        $resa = $lecli->select_client($_POST['mdpclient'],$conn);
        $datacli=  $resa->fetch();
        $idclient = $datacli -> idclients;
        header('Location: traitement_note_repas.php?idcli='.$idclient);
 }
 else
 {
   header('Location:../client.php');
 }
}
 ?>

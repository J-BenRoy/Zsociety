<meta charset="utf-8">
<?php
include 'include/haut.inc.php';
$addpro = $_POST['libpro'];
$lepro = new produits('','','');
$lacat = new categorie('','','');
$lepro->ajouter_produit('',$addpro,$conn);
$lastid = $conn->lastInsertId();
?>
<form method="post" action="traitement_ajouter_tarif.php">
    <input type="hidden" name="lastid" value="<?php echo $lastid; ?>">
    <table>
        <tr>
            <th>Catégories</th>
            <th>Tarif Normal</th>
            <th>Tarif Fidélisé</th>
        </tr>
    <?php
                $resa = $lacat->afficher_categorie($conn);
                while($tabcat = $resa->fetch())
                {
                    $tn = "tn".$tabcat->idcat;
                    $tf = "tf".$tabcat->idcat;
                ?>
                    <tr>
                        <td>
                            <?php echo $tabcat->libcat; ?>
                        </td>
                        <td>
                            <input type="text" name="<?php echo $tn; ?>">
                        </td>
                        <td>
                            <input type="text" name="<?php echo $tf; ?>">
                        </td>
                    </tr>
            <?php
                }
            ?>
    </table>
    <input type="submit" value="Ajouter">
</form>
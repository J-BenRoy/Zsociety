<?php
include'../include/haut.inc.php';
$oclient = new clients('','','','','','','','','','','','','','','','','');
$orepas = new repas('','','','','','');
$otypecli = new typeclients('','','');
$otarif = new tarif('','','','');
$datepick = $_POST['date'];
$time = $_POST['time'];
$idtyperep = $_POST['typerep'];
$idcli = $_POST['idcli'];
$produit = json_decode($_POST['produit']);
$prix = 0;

//Recupération de l'id du type du client
$resa = $oclient->afficher_client($idcli,$conn);
$tabcli = $resa->fetch();
$typecli = $tabcli->idtypeclients;

// Selection de la catégorie du client par rapport à son type
$resa = $otypecli->select_categorie($typecli,$conn);
$tabtypecli = $resa->fetch();
$catecli = $tabtypecli->idcat;

foreach($produit as $prod => $value)
{
	$resa = $otarif->afficher_tarif_idproduits($catecli,$value,$conn);
	$tabtarif = $resa->fetch();
	$tarif += $tabtarif->tarifN;
}

//Requete insertion d'un nouveau repas
$orepas->nouveau_repas('',$datepick,$time,$typecli,$idcli,$idtyperep,$tarif,1,$conn);
?>
<?php
include 'include/haut.inc.php';
$addcate = $_POST['cate'];
$addtf = $_POST['tf'];
$addtn = $_POST['tn'];
$lepro = new produits('','','');
$lacat = new categorie('','','');
$letarif = new tarif('','','','');
$lepro -> affiche_produit($conn);
$lacat->ajout_categorie($addcate,$conn);
Header('Location:../categorie.php');
?>
<?php
include '../include/haut.inc.php';
$note = $_POST['note'];
$idrepas = $_POST['idrepas'];
$lerepas = new repas('','','','','','');
if($note <= 20)
{
  $lerepas -> update_note($note,$idrepas,$conn);
}
else {
  echo 'erreur';
}
?>

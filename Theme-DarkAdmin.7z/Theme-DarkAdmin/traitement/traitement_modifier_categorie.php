<?php
include 'include/haut.inc.php';
$lacat = new categorie('','',$conn);
$resa = $lacat->afficher_categorie($conn);

//Modification des catégories 
if(isset($_POST['modifcate']))
{
    while($tabcat =$resa->fetch()) 
    { 
        $namelib = "libcat".$tabcat->idcat;
        echo $namelib;
        $lib = $_POST[$namelib];
        
        $lacat->maj_categorie($tabcat->idcat,$lib,$conn);
    }
}
Header("Location:../categorie.php");
?>
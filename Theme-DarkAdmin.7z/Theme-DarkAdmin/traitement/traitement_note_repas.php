<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/local.css" />
<style>
table
{
    border-collapse: collapse;
}
td, th
{
    border: 1px solid black;
}
</style>
<?php
include'include/haut.inc.php';
$idcli = $_GET['idcli'];
$lerepas = new repas('','','','','','');
$resa = $lerepas -> repas_client($idcli,$conn);
?>
<form method="post" action="traitement_modifier_note.php">
<table>
  <tr>
    <th>Date</th>
    <th>Heure</th>
    <th>Prix</th>
    <th>Note</th>
  </tr>
  <?php
  while($tabrep = $resa->fetch())
  {
    ?>
    <tr>
      <td><?php echo $tabrep ->daterepas; ?></td>
      <td><?php echo $tabrep ->heurerepas; ?></td>
      <td><?php echo $tabrep ->prix; ?></td>
      <td><input type="text" style="color:black;" name="note" value="<?php echo $tabrep ->note; ?>/20"><input type="submit" style="color:black;" name="ajouter" value="Ajouter"></td>
    </tr>
    <input type="hidden" name="idrepas" value="<?php echo $tabrep->idrepas; ?>"
    <?php
  }
  ?>
</table>
</form>

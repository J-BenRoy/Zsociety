<?php
include'../include/haut.inc.php';
$idprod = $_POST['idproduit'];
$leprod = new produits('','','');
$letarif = new tarif('','','','');
$letarif -> update_valide($idprod,$conn);
$leprod -> update_valide($idprod,$conn);
Header("Location:../produit.php");
?>

<?php
include'include/haut.inc.php';
$idprod = $_POST['liste'];
$leprod = new produits('','',''); 
$leprod -> update_valide($idprod,$conn);
Header("Location:../produit.php");
?>
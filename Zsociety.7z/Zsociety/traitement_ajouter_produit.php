<?php
include 'include/haut.inc.php';
$addpro = $_POST['libpro'];
$addtn = $_POST['tn'];
$addtf = $_POST['tf'];
$lepro = new produits('','','');
$lepro->ajouter_produit('',$addpro,$conn);
$lepro->ajouter_tarif($addtf,$addtn,$conn);
Header('Location:afficher_categorie.php');
?>
<?php
include 'include/haut.inc.php';
$leprod = new produits('','','');
?>
<html>
    <head>
        <title>Safe and self</title>
        <meta charset="utf-8">
    </head>
    <body>
        <form method="post" action="traitement_ajouter_produit.php">
            <label>Libellé</label>
            <input type="text" name="libpro"><br>
            <label>Tarif Normal</label>
            <input type="text" name="tn"><br>
            <label>Tarif fidélisé</label>
            <input type="text" name="tf"><br>
            <input type="submit" name="ajoucat" value="Ajouter">
        </form>
        
        
        <form method="post" action="traitement_modifier_produit.php">
	<?php
        $resa = $leprod->affiche_produit($conn);
		while($tabpro =$resa->fetch()) 
		{ ?>
            <?php
            $namelib = "libpro".$tabpro->idproduits;
            ?>
          
			<input type="text" name="<?php echo $namelib ?>" value="<?php echo $tabpro->libproduits; ?>">
            <input type="hidden" name="idcat" value="<?php echo $tabpro->idproduits; ?>"><br>
		<?php
		}?>
            <input type="submit" name="modifcate" value="Modifier">
        </form>
    </body>
</html>
<html>
    <head>
        <link href='http://fonts.googleapis.com/css?family=Raleway:500' rel='stylesheet' type='text/css'>
        <link href="css/passageclients_css.css">
          <link href="css/bootstrap.min.css" rel="stylesheet">
    
        <!-- Custom CSS -->
        <link href="css/sb-admin.css" rel="stylesheet">
    
        <!-- Morris Charts CSS -->
        <link href="css/plugins/morris.css" rel="stylesheet">
    
        <!-- Custom Fonts -->
        <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
          <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
            <link rel="stylesheet" href="/resources/demos/style.css">
            <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
            <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
            <script>
            $( function() {
                $( "#datepicker" ).datepicker( $.datepicker.regional[ "fr" ] );
            } );
            </script>
    </head>
    <body>
        <div class="middlePage" >
            <div class="page-header">
                <h1 class="logo">Passage</h1>
            </div>
            <div class="panel panel-info">
                <div class="panel-heading">
                </div>
                <div class="panel-body">
                    <div class="row">
                        <label>Date</label>
                        <div id="datepicker"></div>
                        <div class="col-md-7" style="border-left:1px solid #ccc;height:160px">
                            <label>Repas</label>
                            <select>
                                <option>Midi</option>
                                <option>Soir</option>
                            </select><br>
                            <button type="button" class="btn btn-success">Success</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
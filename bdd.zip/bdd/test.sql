-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Jeu 23 Mars 2017 à 18:43
-- Version du serveur :  5.7.9
-- Version de PHP :  5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `test`
--

-- --------------------------------------------------------

--
-- Structure de la table `administrateur`
--

DROP TABLE IF EXISTS `administrateur`;
CREATE TABLE IF NOT EXISTS `administrateur` (
  `Identifiant` varchar(250) NOT NULL,
  `Motdepasse` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `administrateur`
--

INSERT INTO `administrateur` (`Identifiant`, `Motdepasse`) VALUES
('Benjamin', '14160611'),
('aa', 'aa');

-- --------------------------------------------------------

--
-- Structure de la table `civilite`
--

DROP TABLE IF EXISTS `civilite`;
CREATE TABLE IF NOT EXISTS `civilite` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `rue` varchar(50) NOT NULL,
  `ville` varchar(50) NOT NULL,
  `tel` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `civilite`
--

INSERT INTO `civilite` (`id`, `rue`, `ville`, `tel`, `email`) VALUES
(2, '4 impasse des chenes', '19100 Brive-la-Gaillarde – France', '(+33) 6 49 72 94 34', 'roybenjamin16@outlook.fr');

-- --------------------------------------------------------

--
-- Structure de la table `competence`
--

DROP TABLE IF EXISTS `competence`;
CREATE TABLE IF NOT EXISTS `competence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `php` varchar(10) NOT NULL,
  `css` int(10) NOT NULL,
  `html` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `competence`
--

INSERT INTO `competence` (`id`, `php`, `css`, `html`) VALUES
(1, '50', 89, 70);

-- --------------------------------------------------------

--
-- Structure de la table `cv`
--

DROP TABLE IF EXISTS `cv`;
CREATE TABLE IF NOT EXISTS `cv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cv` varchar(1500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `cv`
--

INSERT INTO `cv` (`id`, `cv`) VALUES
(1, 'CV/CV.pdf');

-- --------------------------------------------------------

--
-- Structure de la table `donnee`
--

DROP TABLE IF EXISTS `donnee`;
CREATE TABLE IF NOT EXISTS `donnee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` varchar(1500) NOT NULL,
  `adressecont` varchar(1500) NOT NULL,
  `telfixe` varchar(1500) NOT NULL,
  `telmob` varchar(1500) NOT NULL,
  `email` varchar(1500) NOT NULL,
  `CP` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `donnee`
--

INSERT INTO `donnee` (`id`, `adresse`, `adressecont`, `telfixe`, `telmob`, `email`, `CP`) VALUES
(2, '4 impasse des chÃªnes', '<strong> Adresse </strong> 4 impasse des chÃªnes, Brive, France', '05.87.49.46.07', '06.49.72.94.34', 'roybenjamin16@outlook.fr', 0);

-- --------------------------------------------------------

--
-- Structure de la table `language`
--

DROP TABLE IF EXISTS `language`;
CREATE TABLE IF NOT EXISTS `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `francais` int(100) NOT NULL,
  `anglais` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `language`
--

INSERT INTO `language` (`id`, `francais`, `anglais`) VALUES
(1, 99, 63);

-- --------------------------------------------------------

--
-- Structure de la table `mail`
--

DROP TABLE IF EXISTS `mail`;
CREATE TABLE IF NOT EXISTS `mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(1000) NOT NULL,
  `mail` varchar(1000) NOT NULL,
  `subject` varchar(1000) NOT NULL,
  `message` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `mail`
--

INSERT INTO `mail` (`id`, `nom`, `mail`, `subject`, `message`) VALUES
(1, '', '', 'dfvdfvdf', 'vfdvfdvdf'),
(2, '', '', 'dfvdfvdf', 'vfdvfdvdf'),
(3, 'fegfg', 'roybenjamindu19@gmail.com', 'sdvsd', 'dvdfvd');

-- --------------------------------------------------------

--
-- Structure de la table `nom_comp`
--

DROP TABLE IF EXISTS `nom_comp`;
CREATE TABLE IF NOT EXISTS `nom_comp` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `comp1` varchar(50) NOT NULL,
  `comp2` varchar(50) NOT NULL,
  `comp3` varchar(50) NOT NULL,
  `comp4` varchar(50) NOT NULL,
  `comp5` varchar(50) NOT NULL,
  `comp6` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `nom_comp`
--

INSERT INTO `nom_comp` (`id`, `comp1`, `comp2`, `comp3`, `comp4`, `comp5`, `comp6`) VALUES
(1, 'PHP', 'Javascript', 'CSS', 'HTML', 'Boostrap', 'SQL');

-- --------------------------------------------------------

--
-- Structure de la table `ppe`
--

DROP TABLE IF EXISTS `ppe`;
CREATE TABLE IF NOT EXISTS `ppe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lib` varchar(250) NOT NULL,
  `photo1` varchar(250) NOT NULL,
  `photo2` varchar(250) NOT NULL,
  `photo3` varchar(250) NOT NULL,
  `descriptif` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `ppe`
--

INSERT INTO `ppe` (`id`, `lib`, `photo1`, `photo2`, `photo3`, `descriptif`) VALUES
(27, 'cybernet', '../back-end/image/Capture.PNG', 'image/', 'image/', '');

-- --------------------------------------------------------

--
-- Structure de la table `presentation`
--

DROP TABLE IF EXISTS `presentation`;
CREATE TABLE IF NOT EXISTS `presentation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `presentation` varchar(1500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `presentation`
--

INSERT INTO `presentation` (`id`, `presentation`) VALUES
(1, 'Bonjour,<br> Je m''appelle Benjamin Roy, actuellement en BTS SIO aux lycÃ©e Marguerite Bahuet. <br> Le brevet de technicien supÃ©rieur Services informatiques aux organisations est un cursus d''Ã©tudes se dÃ©roulant sur deux ans, DÃ¨s le deuxiÃ¨me semestre de la premiÃ¨re annÃ©e, une option doit Ãªtre choisie par l''Ã©tudiant entre : \r\n              <br><br>Solutions Logicielles et Applications MÃ©tier (SLAM) ;<br><br>Solutions dâ€™Infrastructure, SystÃ¨mes et RÃ©seaux (SISR).<br><br>J''ai choisis SLAM, la principale raison est l''amusement que je ressens en codant.');

-- --------------------------------------------------------

--
-- Structure de la table `réalisations`
--

DROP TABLE IF EXISTS `réalisations`;
CREATE TABLE IF NOT EXISTS `réalisations` (
  `librea` int(11) NOT NULL AUTO_INCREMENT,
  `comrea` varchar(500) NOT NULL,
  `photo1` varchar(500) NOT NULL,
  `photo2` varchar(500) NOT NULL,
  `lienrea` varchar(500) NOT NULL,
  PRIMARY KEY (`librea`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

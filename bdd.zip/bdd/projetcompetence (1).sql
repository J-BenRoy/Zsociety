-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Jeu 23 Mars 2017 à 18:42
-- Version du serveur :  5.7.9
-- Version de PHP :  5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `projetcompetence`
--

-- --------------------------------------------------------

--
-- Structure de la table `account`
--

DROP TABLE IF EXISTS `account`;
CREATE TABLE IF NOT EXISTS `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `salt` varchar(255) COLLATE utf8_bin NOT NULL,
  `validation_code` varchar(255) COLLATE utf8_bin NOT NULL,
  `secret_question` varchar(20) COLLATE utf8_bin NOT NULL,
  `secret_response` varchar(20) COLLATE utf8_bin NOT NULL,
  `creation_date` datetime NOT NULL,
  `isactive` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `grade`
--

DROP TABLE IF EXISTS `grade`;
CREATE TABLE IF NOT EXISTS `grade` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `grade`
--

INSERT INTO `grade` (`id`, `designation`, `created_at`, `updated_at`) VALUES
(1, 'Membre', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'Redacteur', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'Administrateur', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `port_activite`
--

DROP TABLE IF EXISTS `port_activite`;
CREATE TABLE IF NOT EXISTS `port_activite` (
  `idc` smallint(6) NOT NULL,
  `idDomaine` smallint(6) NOT NULL,
  `nomenclature` char(6) NOT NULL,
  `lngutile` smallint(6) NOT NULL,
  `libelle` varchar(150) NOT NULL,
  PRIMARY KEY (`idc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `port_activite`
--

INSERT INTO `port_activite` (`idc`, `idDomaine`, `nomenclature`, `lngutile`, `libelle`) VALUES
(1, 1, 'A1.1.1', 54, 'Analyse du cahier des charges d''un service à produire'),
(2, 1, 'A1.1.2', 47, 'Étude de l''impact de l''intégration d''un service sur le système informatique'),
(3, 1, 'A1.1.3', 47, 'Étude des exigences liées à la qualité attendue d''un service'),
(4, 2, 'A1.2.1', 49, 'Élaboration et présentation d''un dossier de choix de solution technique'),
(5, 2, 'A1.2.2', 54, 'Rédaction des spécifications techniques de la solution retenue (adaptation d''une solution existante ou réalisation d''une nouvelle solution)'),
(6, 2, 'A1.2.3', 57, 'Évaluation des risques liés à l''utilisation d''un service'),
(7, 2, 'A1.2.4', 51, 'Détermination des tests nécessaires à la validation d''un service'),
(8, 2, 'A1.2.5', 37, 'Définition des niveaux d''habilitation associés à un service'),
(9, 3, 'A1.3.1', 49, 'Test d''intégration et d''acceptation d''un service'),
(10, 3, 'A1.3.2', 51, 'Définition des éléments nécessaires à la continuité d''un service'),
(11, 3, 'A1.3.3', 56, 'Accompagnement de la mise en place d''un nouveau service'),
(12, 3, 'A1.3.4', 25, 'Déploiement d''un service'),
(13, 4, 'A1.4.1', 25, 'Participation à un projet'),
(14, 4, 'A1.4.2', 47, 'Évaluation des indicateurs de suivi d''un projet et justification des écarts'),
(15, 4, 'A1.4.3', 22, 'Gestion des ressources'),
(16, 5, 'A2.1.1', 53, 'Accompagnement des utilisateurs dans la prise en main d''un service'),
(17, 5, 'A2.1.2', 50, 'Évaluation et maintien de la qualité d''un service'),
(18, 6, 'A2.2.1', 32, 'Suivi et résolution d''incidents'),
(19, 6, 'A2.2.2', 45, 'Suivi et réponse à des demandes d''assistance'),
(20, 6, 'A2.2.3', 37, 'Réponse à une interruption de service'),
(21, 7, 'A2.3.1', 58, 'Identification, qualification et évaluation d''un problème'),
(22, 7, 'A2.3.2', 41, 'Proposition d''amélioration d''un service'),
(23, 8, 'A3.1.1', 45, 'Proposition d''une solution d''infrastructure'),
(24, 8, 'A3.1.2', 58, 'Maquettage et prototypage d''une solution d''infrastructure'),
(25, 8, 'A3.1.3', 48, 'Prise en compte du niveau de sécurité nécessaire à une infrastructure'),
(26, 9, 'A3.2.1', 57, 'Installation et configuration d''éléments d''infrastructure'),
(27, 9, 'A3.2.2', 49, 'Remplacement ou mise à jour d''éléments défectueux ou obsolètes'),
(28, 9, 'A3.2.3', 41, 'Mise à jour de la documentation technique d''une solution d''infrastructure'),
(29, 10, 'A3.3.1', 50, 'Administration sur site ou à distance des éléments d''un réseau, de serveurs, de services et d''équipements terminaux'),
(30, 10, 'A3.3.2', 59, 'Planification des sauvegardes et gestion des restaurations'),
(31, 10, 'A3.3.3', 42, 'Gestion des identités et des habilitations'),
(32, 10, 'A3.3.4', 43, 'Automatisation des tâches d''administration'),
(33, 10, 'A3.3.5', 51, 'Gestion des indicateurs et des fichiers d''activité'),
(34, 11, 'A4.1.1', 39, 'Proposition d''une solution applicative'),
(35, 11, 'A4.1.2', 51, 'Conception ou adaptation de l''interface utilisateur d''une solution applicative'),
(36, 11, 'A4.1.3', 47, 'Conception ou adaptation d''une base de données'),
(37, 11, 'A4.1.4', 59, 'Définition des caractéristiques d''une solution applicative'),
(38, 11, 'A4.1.5', 35, 'Prototypage de composants logiciels'),
(39, 11, 'A4.1.6', 53, 'Gestion d''environnements de développement et de test'),
(40, 11, 'A4.1.7', 54, 'Développement, utilisation ou adaptation de composants logiciels'),
(41, 11, 'A4.1.8', 49, 'Réalisation des tests nécessaires à la validation d''éléments adaptés ou développés'),
(42, 11, 'A4.1.9', 40, 'Rédaction d''une documentation technique'),
(43, 11, 'A4.1.1', 45, 'Rédaction d''une documentation d''utilisation'),
(44, 12, 'A4.2.1', 44, 'Analyse et correction d''un dysfonctionnement, d''un problème de qualité de service ou de sécurité'),
(45, 12, 'A4.2.2', 52, 'Adaptation d''une solution applicative aux évolutions de ses composants'),
(46, 12, 'A4.2.3', 57, 'Réalisation des tests nécessaires à la mise en production d''éléments mis à jour'),
(47, 12, 'A4.2.4', 42, 'Mise à jour d''une documentation technique'),
(48, 13, 'A5.1.1', 45, 'Mise en place d''une gestion de configuration'),
(49, 13, 'A5.1.2', 44, 'Recueil d''informations sur une configuration et ses éléments'),
(50, 13, 'A5.1.3', 45, 'Suivi d''une configuration et de ses éléments'),
(51, 13, 'A5.1.4', 43, 'Étude de propositions de contrat de service (client, fournisseur)'),
(52, 13, 'A5.1.5', 40, 'Évaluation d''un élément de configuration ou d''une configuration'),
(53, 13, 'A5.1.6', 44, 'Évaluation d''un investissement informatique'),
(54, 14, 'A5.2.1', 50, 'Exploitation des référentiels, normes et standards adoptés par le prestataire informatique'),
(55, 14, 'A5.2.2', 20, 'Veille technologique'),
(56, 14, 'A5.2.3', 37, 'Repérage des compléments de formation ou d''auto-formation utiles à l''acquisition de nouvelles compétences'),
(57, 14, 'A5.2.4', 51, 'Étude dune technologie, d''un composant, d''un outil ou d''une méthode');

-- --------------------------------------------------------

--
-- Structure de la table `possede`
--

DROP TABLE IF EXISTS `possede`;
CREATE TABLE IF NOT EXISTS `possede` (
  `idppe` int(3) NOT NULL,
  `idcompetence` varchar(6) NOT NULL,
  `ouinon` tinyint(1) NOT NULL,
  PRIMARY KEY (`idppe`,`idcompetence`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `possede`
--

INSERT INTO `possede` (`idppe`, `idcompetence`, `ouinon`) VALUES
(81, 'A5.2.4', 0),
(81, 'A5.2.3', 0),
(81, 'A5.2.2', 0),
(81, 'A5.2.1', 0),
(81, 'A5.1.6', 0),
(81, 'A5.1.5', 0),
(81, 'A5.1.4', 0),
(81, 'A5.1.3', 0),
(81, 'A5.1.2', 1),
(81, 'A5.1.1', 0),
(81, 'A4.2.4', 0),
(81, 'A4.2.3', 0),
(81, 'A4.2.2', 0),
(81, 'A4.2.1', 1),
(81, 'A4.1.9', 1),
(81, 'A4.1.8', 1),
(81, 'A4.1.7', 0),
(81, 'A4.1.6', 0),
(81, 'A4.1.5', 0),
(81, 'A4.1.4', 0),
(81, 'A4.1.3', 1),
(81, 'A4.1.2', 0),
(81, 'A4.1.1', 0),
(81, 'A3.3.5', 0),
(81, 'A3.3.4', 0),
(81, 'A3.3.3', 0),
(81, 'A3.3.2', 0),
(81, 'A3.3.1', 0),
(81, 'A3.2.3', 0),
(81, 'A3.2.2', 0),
(81, 'A3.2.1', 1),
(81, 'A3.1.3', 0),
(81, 'A3.1.2', 0),
(81, 'A3.1.1', 0),
(81, 'A2.3.2', 0),
(81, 'A2.3.1', 0),
(81, 'A2.2.3', 0),
(81, 'A2.2.2', 0),
(81, 'A2.2.1', 0),
(81, 'A2.1.2', 0),
(81, 'A2.1.1', 0),
(81, 'A1.4.3', 0),
(81, 'A1.4.2', 0),
(81, 'A1.4.1', 0),
(81, 'A1.3.4', 0),
(81, 'A1.3.3', 0),
(81, 'A1.3.2', 0),
(81, 'A1.3.1', 0),
(81, 'A1.2.5', 0),
(81, 'A1.2.4', 0),
(81, 'A1.2.3', 0),
(81, 'A1.2.2', 0),
(81, 'A1.2.1', 0),
(81, 'A1.1.3', 0),
(81, 'A1.1.2', 1),
(81, 'A1.1.1', 1),
(0, 'A5.2.4', 0),
(0, 'A5.2.3', 0),
(0, 'A5.2.2', 0),
(0, 'A5.2.1', 0),
(0, 'A5.1.6', 0),
(0, 'A5.1.5', 0),
(0, 'A5.1.4', 0),
(0, 'A5.1.3', 0),
(0, 'A5.1.2', 0),
(0, 'A5.1.1', 0),
(0, 'A4.2.4', 0),
(0, 'A4.2.3', 0),
(0, 'A4.2.2', 0),
(0, 'A4.2.1', 0),
(0, 'A4.1.9', 0),
(0, 'A4.1.8', 0),
(0, 'A4.1.7', 0),
(0, 'A4.1.6', 0),
(0, 'A4.1.5', 0),
(0, 'A4.1.4', 0),
(0, 'A4.1.3', 0),
(0, 'A4.1.2', 0),
(0, 'A4.1.1', 0),
(0, 'A3.3.5', 0),
(0, 'A3.3.4', 0),
(0, 'A3.3.3', 0),
(0, 'A3.3.2', 0),
(0, 'A3.3.1', 0),
(0, 'A3.2.3', 0),
(0, 'A3.2.2', 0),
(0, 'A3.2.1', 0),
(0, 'A3.1.3', 0),
(0, 'A3.1.2', 0),
(0, 'A3.1.1', 0),
(0, 'A2.3.2', 0),
(0, 'A2.3.1', 0),
(0, 'A2.2.3', 0),
(0, 'A2.2.2', 0),
(0, 'A2.2.1', 0),
(0, 'A2.1.2', 0),
(0, 'A2.1.1', 0),
(0, 'A1.4.3', 0),
(0, 'A1.4.2', 0),
(0, 'A1.4.1', 0),
(0, 'A1.3.4', 0),
(0, 'A1.3.3', 0),
(0, 'A1.3.2', 0),
(0, 'A1.3.1', 0),
(0, 'A1.2.5', 0),
(0, 'A1.2.4', 0),
(0, 'A1.2.3', 0),
(0, 'A1.2.2', 0),
(0, 'A1.2.1', 0),
(0, 'A1.1.3', 0),
(0, 'A1.1.2', 0),
(0, 'A1.1.1', 0);

-- --------------------------------------------------------

--
-- Structure de la table `projets`
--

DROP TABLE IF EXISTS `projets`;
CREATE TABLE IF NOT EXISTS `projets` (
  `idppe` int(11) NOT NULL AUTO_INCREMENT,
  `lib` varchar(50) NOT NULL,
  `description` varchar(250) NOT NULL,
  `lienphoto1` varchar(250) NOT NULL,
  `lienapplication` varchar(250) NOT NULL,
  PRIMARY KEY (`idppe`)
) ENGINE=MyISAM AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `projets`
--

INSERT INTO `projets` (`idppe`, `lib`, `description`, `lienphoto1`, `lienapplication`) VALUES
(81, 'Cybernet', '', 'image/', '');

-- --------------------------------------------------------

--
-- Structure de la table `test`
--

DROP TABLE IF EXISTS `test`;
CREATE TABLE IF NOT EXISTS `test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lib` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `test`
--

INSERT INTO `test` (`id`, `lib`) VALUES
(1, '$lib'),
(2, 'lib'),
(3, 'lib');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

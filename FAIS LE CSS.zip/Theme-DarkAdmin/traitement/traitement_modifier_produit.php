<?php
include 'include/haut.inc.php';
$lepro= new produits('','','');
$resa = $lepro->affiche_produit($conn);
while($tabpro =$resa->fetch()) 
{ 
    $namelib = "libpro".$tabpro->idproduits;
    echo $namelib;
    $lib = $_POST[$namelib];
    
    $lepro->maj_produit($tabpro->idproduits,$lib,$conn);
    Header('Location:../produit.php');
}
?>
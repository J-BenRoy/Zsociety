<?php
include 'include/haut.inc.php';
?>
<!doctype html>
<html lang="en">
<head>
<style>
</style>
<meta charset="utf-8">
<!--  JUSTE DU CSS -->
<link rel="stylesheet"
	href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/local.css" />
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>

<!--  j'me co a toutes mes pages js, yeahhh  -->

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript"
	src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="js/list_client_passage.js"></script>
<script type="text/javascript" src="js/verif_eleve_ajax.js"></script>

<!--  Petit fonction pour le datepicker -->

<script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
</script>

</head>
<body>

    <div id="wrapper">

        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Back to Admin</a>
            </div>
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <?php
                include'include/header.inc.php';
                ?>
                <ul class="nav navbar-nav navbar-right navbar-user">
                    <li class="dropdown user-dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> Steve Miller<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="#"><i class="fa fa-user"></i> Profile</a></li>
                            <li><a href="#"><i class="fa fa-gear"></i> Settings</a></li>
                            <li class="divider"></li>
                            <li><a href="#"><i class="fa fa-power-off"></i> Log Out</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>

	<!--  Ici on met juste en place le formulaire pour recuperer la date et le type repas -->

	<div class="container">
		<form method="post" id="dateform">
			<div class="col-md-2">
				<p>
					Date: <input type="text" id="datepicker" name="date">
				</p>
			</div>
			<br> <br> <br>
			<div class="col-md-2">
				Service : <select id="selectbasic" name="typerepas"
					class="form-control">">
					<option value="matin">Matin</option>
					<option value="midi">Midi</option>
					<option value="soir">Soir</option>
				</select>
			</div>
			<br> <br> <br> <br>
			<div class="col-md-2">
				<input type="submit" name="valider" id="valider" value="Valider">
			</div>
			</p>
		</form>
	</div>
	<br>

	<!--  Le if, la frero, il permet d'ouvrir la suite pour choisir le client, comme vous pouvez le constater on verifie 1. que la date n'est pas nul 2. et qu'il y a un resultat pour les deux donn�es. -->
	
<?php
if (isset ( $_POST ['valider'] ) and isset ( $_POST ['date'] ) and isset ( $_POST ['typerepas'] ) and ($_POST ['date'] != null)) {
	?> 
	<div class="container">
		<div class="content">
			<form method="post" action="passagetraitement.php">
				<div class="col-md-4">
					<div class="label_div">Client</div>
					<div class="input_container">

						<!--  si tu veux faire une liste d'autocompletion tu dois mettre onkeyup="autocomplet()"  (A verifier)  -->

						<input type="text" id="nomclient" onkeyup="autocomplet()"> <input
							type="hidden" id="idclient" name="idclient"
							onkeyup="autocomplet()">

						<!--  Ici ca permet juste d'afficher la liste "ul"  -->

						<ul id="list_nomclient"></ul>
					</div>

					<!--  un vieux checkbox  -->

					<div id="repas">
			<?php
	$leproduit = new produits ( '', '', '' );
	$resa = $leproduit->affiche_produit ( $conn );
	while ( $tabrepas = $resa->fetch () ) {
		?>
					<input id="checkbox" type="checkbox"
							name="<?php echo $tabrepas -> idproduits;?>">
					<?php echo $tabrepas -> libproduits;?>
					<?php
	}
	?>	
				<input type="submit" name="valider" id="valider" value="Valider">
					</div>
				</div>
			</form>
		</div>
	</div>
	<div id="success"></div>
        <?php
}
?>
<script type="text/javascript">
jQuery('#repas').fadeOut();

/script>
</body>
</html>
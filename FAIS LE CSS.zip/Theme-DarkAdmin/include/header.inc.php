<ul id="active" class="nav navbar-nav side-nav">
    <li class="selected"><a href="passage.php"><i class="fa fa-cutlery"></i> Passage</a></li>
    <li><a href="client.php"><i class="glyphicon glyphicon-user"></i> Client</a></li>
    <li><a href="categorie.php"><i class="fa fa-child"></i> categorie</a></li>
    <li><a href="produit.php"><i class="fa fa-coffee"></i> Produits</a></li>
    <li><a href="tarif.php"><i class="fa fa-euro"></i> Tarifs</a></li>
    <li><a href="#l"><i class="fa fa-bar-chart-o"></i> Statistiques</a></li>
</ul>
<?php
$conn = new PDO('mysql:host=localhost;dbname=safeself;charset=utf8','root','');
?>
<?php
include'../include/haut.inc.php';
$radio = $_POST['radios'];
if ($radio == '1'){
    $SQL = "
    SELECT nomclients,prenomclients, daterepas, heurerepas, prix, libtyperepas
    FROM repas, clients, typerepas, typeclients, categorie 
    WHERE repas.idclients = clients.idclients 
    AND repas.idtyperepas = typerepas.idtyperepas 
    AND categorie.idcat = typeclients.idcat
    AND clients.idtypeclients = typeclients.idtypeclients
    ";
} else {
    $SQL = "
    SELECT SUM(prix)
    FROM repas, clients, typerepas, typeclients, categorie 
    WHERE repas.idclients = clients.idclients 
    AND repas.idtyperepas = typerepas.idtyperepas 
    AND categorie.idcat = typeclients.idcat
    AND clients.idtypeclients = typeclients.idtypeclients
    ";
} 



$nom = $_POST['name'];
if ($nom == ""){

} else {
    $RQ = " AND clients.nomclients = '$nom'";
    $SQL = $SQL.$RQ;
}


$prenom = $_POST['prenom'];
if ($prenom == ""){

} else {
    $RQ = " AND clients.prenomclients = '$prenom'";
    $SQL = $SQL.$RQ;
}

$cat = $_POST['cat'];
if ($cat == "0"){

} else {
    $RQ = " AND categorie.idcat = '$cat'";
    $SQL = $SQL.$RQ;
}

$type = $_POST['type'];
if ($type == "0"){

} else {
    $RQ = " AND typeclients.idtypeclients = '$type'";
    $SQL = $SQL.$RQ;
}


$DD = $_POST['datepicker1'];
$DF = $_POST['datepicker2'];

if ($DD == ""){

} elseif ($DF == "") {
    $RQ = " AND repas.daterepas BETWEEN '$DD' AND NOW()";
    $SQL = $SQL.$RQ;
} else {
    $RQ = " AND repas.daterepas BETWEEN '$DD' AND '$DF'";
    $SQL = $SQL.$RQ;
}

echo $SQL;




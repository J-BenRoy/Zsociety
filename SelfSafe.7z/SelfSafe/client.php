<?php
include 'include/haut.inc.php';
?>
<!doctype html>
<html lang="en">
<head>
<style>
</style>
<meta charset="utf-8">
<!--  JUSTE DU CSS -->
<link rel="stylesheet"
	href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/local.css" />
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>

<!--toutes mes pages js -->

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="js/list_client_passage.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.5.1.min.js"></script>
<script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery.ui/1.8.10/jquery-ui.js"></script>
    </head>
        <body>
            <div id="wrapper">
                <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="index.php">Safe &amp; Self</a>
                    </div>
                    <div class="collapse navbar-collapse navbar-ex1-collapse">
                        <?php
                        include'include/header.inc.php';
                        ?>
                    </div>
                </nav>
          </div>
          <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h3 class="panel-title"><i class="glyphicon glyphicon-search"></i> Connection </h3>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="col-md-5">
                                        <label>Identifiants :</label>
                                    <br>
                              <form method="post" action="traitement/traitement_client.php">
                                  nom :<input type="text" name="nomclient"><br>
                                  Password :<input type="text" name="mdpclient"><br>
                                  <input type="submit" value="valider">
                            </form>
                    </div>
                </div>
              </div>
            </div>
            
  </body>
</html>

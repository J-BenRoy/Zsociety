<?php
//Auto completion des produits
include'../haut.inc.php';

$keyword = '%'.$_POST['keyword'].'%';  // recupere la lettre saisie dans le champ texte en provenance de JS

// Requête de selection

$sql = "SELECT * FROM typeproduit WHERE valide='1'";
if(is_numeric($keyword)){
	$sql =$sql." AND libtypeprod = '$keyword'";
}
else{
	$sql =$sql." AND libtypeprod LIKE (:keyword) ORDER BY libtypeprod";
}
$query = $conn->prepare($sql);
$query->bindParam(':keyword', $keyword, PDO::PARAM_STR);
$query->execute();
$list = $query->fetchAll();
foreach ($list as $rs) {
	//  Juste l'affichage de la liste, tu as vu comment ca marche hier
	$libtypeprod = str_replace($_POST['keyword'],$_POST['keyword'],' '.$rs['libtypeprod'].'<br><br>');
	// S�lection
    echo '<li onclick="set_item(\''.str_replace("'", "\'",$rs['libtypeprod']).'\',\''.str_replace("'", "\'", $rs['idtypeproduit']).'\')">'.$libtypeprod.'</li>';
}
?>

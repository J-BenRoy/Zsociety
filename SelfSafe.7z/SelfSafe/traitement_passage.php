<?php
$conn = new PDO('mysql:host=localhost;dbname=safeself;charset=utf8','root','');
$datepick = $_POST['date'];
$time = $_POST['time'];
$idtyperep = $_POST['typerep'];
$idcli = $_POST['idcli'];
$SQL = "INSERT INTO repas VALUES (NULL, '$datepick', '$time', '6.50', '$idcli', '$idtyperep', '', '1')";
$resultat = $conn->query($SQL);
?>
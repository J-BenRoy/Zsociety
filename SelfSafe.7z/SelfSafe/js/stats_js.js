$(document).ready(function() {
    $("#send").click(function() {
        var radio = $('#radios').attr('value');
        var prenom = $('#prenom').attr('value');
        var nom = $('#name').attr('value');
        var cat = $('#cat').attr('value');
        var type = $('#type').attr('value');
        var DD = $('#datepicker1').attr('value');
        var DF = $('#datepicker2').attr('value');
        $.ajax({
            type : "POST",
            url : "traitement_statistique.php",
            data : "&prenom=" + prenom + "&nom=" + name + "&cat=" + cat + "&type=" + type + "&datepicker1=" + datepicker1 + "&datepicker2=" + datepicker2 + "&radios=" + radios,
            success : result,
            dataType : "json"
        });
        return false;
    });
});

function result(data){


    var resultat = '<p>Résultat :&nbsp; Produit <b>'+"</b><br /></p>";

    $('form#aj').hide();

}
<?php
include '/include/bdd.inc.php';
if (isset ($_POST['ajouter'])){
    $lib = $_POST ['lib'];
    $des = addslashes ( $_POST ['descriptif'] );
    $lienapp = addslashes ( $_POST ['lienapp'] );
    $dir = "image/";

    $tmp1 = $_FILES ['photo1'] ['tmp_name'];
    $name1 = $_FILES ['photo1'] ['name'];
    $size1 = $_FILES ['photo1'] ['size'];
    $type1 = $_FILES ['photo1'] ['type'];
    $photo1 = $dir . $name1;
    move_uploaded_file ( $tmp1, $photo1 );
    $SQL = "INSERT INTO projets (lib,description,lienphoto1,lienapplication) VALUES ('$lib','$des','$photo1','$lienapp')";
    var_dump($SQL);
    $resa = $conn->exec ( $SQL );
    $lastId = $conn->lastInsertId ();
    $SQL = "SELECT * FROM port_activite";
    $resultat = $conn->Query ( $SQL );
    $resultat->setFetchMode ( PDO::FETCH_OBJ );
    while ( $unres = $resultat->fetch () ) {
        $idc = $unres->nomenclature;
        $SQL = "INSERT INTO possede(idppe,idcompetence,ouinon) VALUES('$lastId','$idc','0')";
        $result = $conn->exec ( $SQL );
    }
    header ( "Location: projetcreation.php?num=$lastId");
}
if (isset ($_POST['modifier'])){
    $idppe = $_POST['idppe'];
    $lib = $_POST ['lib'];
    $des = addslashes ( $_POST ['description'] );
    $lienapp = addslashes ( $_POST ['lienapplication'] );
    $dir = "image/";
    $tmp = $_FILES ['lienphoto1'] ['tmp_name'];
    $name1 = $_FILES ['lienphoto1'] ['name'];
    $chemin1 = $dir . $name1;
    move_uploaded_file ( $tmp, $chemin1 );
    if ($chemin != 'image/') {
        $SQL = "UPDATE projets SET lienphoto1='$chemin1' where idppe='$idppe'";
        var_dump($SQL);
        $conn->query ( $SQL );
    }

    $SQLupdateprojet = "UPDATE projets
        SET lib='$lib',description='$des',lienapplication='$lienapp' where idppe='$idppe'";
    $resultat = $conn->exec($SQLupdateprojet);


    $SQL = "SELECT * FROM possede
            WHERE idppe = $idppe";
    $resultat = $conn->Query ($SQL);

    while ($resa = $resultat->fetch()){
        $arrayComp[] = $resa['idcompetence'];
    }

    $arrayDif = array_diff($arrayComp, $_POST['lib']);

    foreach($_POST['check'] as $checkbox){
        $conn->exec("UPDATE possede SET ouinon=1 WHERE idcompetence='$checkbox' AND idppe='$idppe'");
    }
    foreach($arrayDif as $unchecked){
        $conn->exec("UPDATE possede SET ouinon=0 WHERE idcompetence='$unchecked' AND idppe='$idppe'");
    }
    header ( "Location: projetcreation.php");
}
if (isset ($_POST['supprimer'])){
    $id = $_POST ['liste'];
    $SQL = "SELECT * FROM projets WHERE idppe='$id'";
    $resa = $conn->query ( $SQL );
    $resa->SetFetchMode ( PDO::FETCH_OBJ );
    $resultat = $resa->fetch ();
    $photo1 = $resultat->photo1;
    if (file_exists ( $photo1 )) {
        unlink ( $photo1 );
    }
    $SQL = "DELETE FROM projets WHERE idppe='$id'";
    $resa = $conn->query ( $SQL );
    var_dump($SQL);
    $SQLdelete = "DELETE FROM possede WHERE idppe='$id'";
    $resa = $conn->query ( $SQLdelete );
    var_dump($SQLdelete);
    header ("Location: projetcreation.php");
}
?>

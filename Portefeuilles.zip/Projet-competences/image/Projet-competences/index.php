
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title></title>
        <script type="text/javascript" src="./_js/jquery-1.3.2.js"></script>
        <script type="text/javascript" src="./_js/ajax.js"></script>

    </head>
    <body>
       <a href="#" id="bla" type="submit" class="btn btn-primary btn-primary"><span class="glyphicon glyphicon-ok">&nbsp;Connexion</span></a>
        <div id="root">
            <form id="produit" method="post" name="produit" action="">
                    <fieldset>
                            <legend>produit</legend>

                            <label for="lib">Libelle:</label>
                            <br />
                            <input type="text" name="lib" id="lib" class="text" size="20" />
                            <br />
                            <label for="tarif">tarif:</label>
                            <br />
                            <input type="text" name="tarif" id="tarif" class="text" size="20" />
                            <br /><br />

                            <button type="submit" class="button positive">&nbsp;Connexion</button>
                    </fieldset>
            </form>
            <div id="success" class="success" style="display:none;"></div>
        </div>
        <script type="text/javascript">
            jQuery('#root').hide();
            $('#bla').click(function(){
                $('#root').show();
            });
        </script>
    </body>
</html>

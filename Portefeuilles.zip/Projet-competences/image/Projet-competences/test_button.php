
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Projets</title>

        <link href="assets/bootstrap/css/bootstrap.css" rel="stylesheet">
    </head>
    <body>

        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header"></div>
            </div>
        </nav>


        <script type="text/javascript" src="./_js/jquery-1.3.2.js"></script>
        <script type="text/javascript" src="./_js/ajax_traitement.js"></script>
        <!-- include -->
        <?php
        include '/include/bdd.inc.php';
        $resa = $conn->query ( "SELECT * FROM projets" );
        $resa->setFetchMode ( PDO::FETCH_OBJ );
        ?>
        <div class="container">
            <div class="row">
                <div class="col-lg-offset-1 col-lg-2">
                    <!-- Bouton -->
                    <!--<button id="hide" type="submit" class="btn btn-primary">&nbsp;Connexion</button> -->
                    <a href="#" id="hide" type="submit" class="btn btn-primary btn-primary"><span class="glyphicon glyphicon-ok">&nbsp;Ajouter</span></a>
                </div>
                <div class="col-lg-offset-2 col-lg-2">
                    <!--<button id="modifier_button" type="submit" class="btn btn-primary"></button>-->
                    <a href="#" id="modifier_button" type="submit" class="btn btn-primary btn-success" name="modifier"><span class="glyphicon glyphicon-cog">&nbsp;Modifier</span></a>
                </div>
                <div class="col-lg-offset-2 col-lg-2">
                    <!--<button id="supprimer_button" type="submit" class="btn btn-primary"></button>-->
                    <a href="#" id="supprimer_button" type="submit" class="btn btn-primary btn-danger"><span class="glyphicon glyphicon-minus-sign">&nbsp;Supprimer</span></a>
                </div>
            </div>
        </div>


        <!-- ajouter -->
        <div id="root">
            <div class="container">
                <div class="row">
                    <div class="col-lg-offset-1 col-lg-2">
                        <form method="post" name ="aj"  id="aj">
                            <br>
                            <fieldset>
                                <legend>Ajouter une ligne</legend>
                                <label for="lib">Libelle:</label>
                                <br />
                                <input type="text" name="lib" id="lib" class="text" size="20" />
                                <br />
                                <label for="description">Decription:</label>
                                <br />
                                <input type="text" name="description" id="description" class="text" size="20" />
                                <br /><br />
                                <label for="lienapplication">Lien:</label>
                                <br />
                                <input type="text" name="lienapplication" id="lienapplication" class="text" size="20" />
                                <br /><br />
                                <label for="lienphoto">Photo:</label>
                                <br />
                                <input type="file" name="lienphoto" id="lienphoto" class="text" size="20" />
                                <br /><br />

                                <button type="submit" class="btn btn-primary" >&nbsp;Ajouter</button>
                            </fieldset>
                        </form>
                        <div id="success" class="success">sx</div>
                    </div>
                </div>
            </div>
        </div>





        <div id="modifier">
            <div class="container">
                <div class="row">
                    <div class="col-lg-offset-5 col-lg-3">
                        <div class="row">
                            <div class="col-lg-9">
                                <br>
                                <?php
                                $resa = $conn->query ( "SELECT * FROM projets" );
                                $resa->setFetchMode ( PDO::FETCH_OBJ );
                                ?>
                                <form method="post" name="liste" action="projetcreation.php" enctype="multipart/form-data">
                                    <legend>Modifier une ligne</legend>
                                    <select name="liste">
                                        <?php
                                        While ( $resultat = $resa->Fetch () ) {
                                        ?>
                                        <option value="<?php echo $resultat -> idppe ?>"> <?php echo $resultat -> lib?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                    <br> <br>
                                    <input type="submit" class="btn btn-sm btn-success" id="modifier_competence" name="modifier_competence" value="Modifier Compétence" >
                                    <br><br>
                                    <input type="submit" class="btn btn-sm btn-success" name="modifier" id="modifer" value="Modifier" >
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php
        include '/include/bdd.inc.php';
        $resa = $conn->query ( "SELECT * FROM projets" );
        $resa->setFetchMode ( PDO::FETCH_OBJ );
        ?>
        <div class="container">
            <div class="row">
                <div class="col-lg-offset-9 col-lg-3">
                    <div id="supprimer">
                        <form method="post" id="liste" name="liste">
                            <div class="row">
                                <div class="col-lg-10">
                                    <br>
                                    <legend>Supprimer une ligne</legend>
                                    <select name="donnee" id="donnee">
                                        <?php
                                        While ( $resultat = $resa->Fetch () ) {
                                        ?>
                                        <option value="<?php echo $resultat -> idppe ?>"> <?php echo $resultat -> lib?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                    <br><br>
                                    <input type="submit" name=supprimer class="btn btn-danger" value="Supprimer">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <script type="text/javascript">
            jQuery('#root').hide();
            jQuery('#modifier').hide();
            jQuery('#supprimer').hide();

            jQuery('#hide').click(function(){
                jQuery('#root').show();
                jQuery('#modifier').hide();
                jQuery('#supprimer').hide();
            });

            jQuery('#modifier_button').click(function(){
                jQuery('#root').hide();
                jQuery('#modifier').show();
                jQuery('#supprimer').hide();
            });

            jQuery('#supprimer_button').click(function(){
                jQuery('#root').hide();
                jQuery('#modifier').hide();
                jQuery('#supprimer').show();
            });
        </script>



    </body>
</html>

<?php


$result = array(

    'lib'  	=> $_POST['lib'],
    'tarif' => $_POST['tarif'],
);

echo json_encode($result);

?>

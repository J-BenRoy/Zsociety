<?php
include '/include/bdd.inc.php';
$id = $_POST['idppe'];
$SQL = "SELECT * FROM projets WHERE idppe='$id'";
$resa = $conn->query ( $SQL );
$resa->SetFetchMode ( PDO::FETCH_OBJ );
$resultat = $resa->fetch ();
$photo1 = $resultat->photo1;
if (file_exists ( $photo1 )) {
    unlink ( $photo1 );
}
$SQL = "DELETE FROM projets WHERE idppe='$id'";
$resa = $conn->query ( $SQL );
$SQLdelete = "DELETE FROM possede WHERE idppe='$id'";
$resa = $conn->query ( $SQLdelete );
?>

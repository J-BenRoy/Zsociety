
$(document).ready(function () {
    $("form#liste").submit(function () {
        var idppe               = $('#idppe').attr('value');
        var lib                 = $('#lib').attr('value');


        $.ajax({
            type: "POST",
            url: "action_suppr.php",
            data: "&idppe=" + idppe + "&lib=" + lib,
            success: result,
            dataType: "json"
            });
        return false;
    });
});


<?php
$result = array(
    'lib'                   => $_POST['lib'],
);
echo json_encode($result);

include '/include/bdd.inc.php';
$lib = $_POST['lib'];

$SQL = "INSERT INTO test (id,lib) VALUES (NULL,'$lib')";
$resa = $conn->exec ( $SQL );

/*
$des = addslashes ( $_POST ['description'] );
$lienapp = addslashes ( $_POST ['lienapplication'] );
$dir = "image/";

$tmp1 = $_FILES ['lienphoto'] ['tmp_name'];
$name1 = $_FILES ['lienphoto'] ['name'];
$size1 = $_FILES ['lienphoto'] ['size'];
$type1 = $_FILES ['lienphoto'] ['type'];
$photo1 = $dir . $name1;
move_uploaded_file ( $tmp1, $photo1 );*/

/*$lastId = $conn->lastInsertId ();
$SQL = "SELECT * FROM port_activite";
$resultat = $conn->Query ( $SQL );
$resultat->setFetchMode ( PDO::FETCH_OBJ );
while ( $unres = $resultat->fetch () ) {
    $idc = $unres->nomenclature;
    $SQL = "INSERT INTO possede(idppe,idcompetence,ouinon) VALUES('$lastId','$idc','0')";
    $result = $conn->exec ( $SQL );
    echo json_encode($result);*/

?>

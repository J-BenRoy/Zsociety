
$(document).ready(function () {
    $("form#aj").submit(function() {
        var lib                 = $('#lib').attr('value');
       /* var description         = $('#description').attr('value');
        var lienapplication     = $('#lienapplication').attr('value');
        var lienphoto           = $('#lienphoto').attr('value');*/


        $.ajax({
            type: "POST",
            url: "action_traitement.php",
            data: "&lib=" + lib,
            success: result,
            dataType: "json"
            });
        return false;
    });
});

function result(data){

    var resultat = '<p>Résultat :&nbsp; lib <b>'+data.lib+'<br /></p>";

    $('form#aj').hide();
    $('div#success').fadeIn("slow");
    $('div#success').append(resultat);

}

<?php
include '/include/bdd.inc.php';
?>
<html>
<head>
   <meta charset="UTF-8">

    <title>Projets</title>

    <link href="assets/bootstrap/css/bootstrap.css" rel="stylesheet">

    <style type="text/css">
        .image_petit {
            width:100px;
            height:100px;
        }
        label{
            margin-left: 15px;
        }
        .add{
            margin-left: 50px;
        }

    </style>

</head>
<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header"></div>
        </div>
    </nav>

<?php

if (!isset ($_GET['num']) and !isset($_POST['liste'])){

    include '/include/bdd.inc.php';
    $resa = $conn->query ( "SELECT * FROM projets" );
    $resa->setFetchMode ( PDO::FETCH_OBJ );
    ?>
    <div class="container">

        <form method="post" action="projettraitement.php" enctype="multipart/form-data">
            Ajouter une ligne : <br>
            <input type="text" name="lib" placeholder="libelle"> <br>
            <input type="text" name="descriptif" placeholder="description"> <br>
            <input type="text" name="lienapp" placeholder="lienapp"> <br><br>
            <input type="file" name="photo1"> <br>
            <input type="submit" name="ajouter" value="ajouter">
        </form>



        <form method="post" name="liste" action="projettraitement.php">
            <legend>Supprimer une ligne :</legend>
                <select name="liste">
                    <?php
                        While ( $resultat = $resa->Fetch () ) {
                    ?>
                        <option value="<?php echo $resultat -> idppe ?>"> <?php echo $resultat -> lib?></option>
                    <?php
                        }
                    ?>
                </select> <input type="submit" name=supprimer class="btn btn-danger" value="Supprimer">
        </form>

            <?php
                $resa = $conn->query ( "SELECT * FROM projets" );
                $resa->setFetchMode ( PDO::FETCH_OBJ );
            ?>
                <form method="post" name="liste" action="projetcreation.php" enctype="multipart/form-data">
                    <legend>Modifier une ligne :</legend>
                    <select name="liste">
                        <?php
                            While ( $resultat = $resa->Fetch () ) {
                        ?>
                            <option value="<?php echo $resultat -> idppe ?>"> <?php echo $resultat -> lib?></option>
                        <?php
                            }
                        ?>
                    </select> <input type="submit" name="modifier" value="Modifier">
                </form>





<?php
}

if(isset ($_GET['num']) or isset ($_POST['modifier'])){
    if(isset ($_POST['liste'])){
        $id = $_POST ['liste'];
    }
    if(isset ($_GET['num'])){
        $id=$_GET['num'];
    }

    $SQL = "SELECT * FROM projets
            WHERE idppe = $id";
    $resultat = $conn->Query ( $SQL );
    $resultat->setFetchMode ( PDO::FETCH_OBJ );
    $resa = $resultat->fetch ();
    ?>



    <div class="container">
        <form method="post" enctype="multipart/form-data" action="projettraitement.php" class="form-horizontal" >
            <fieldset>
            <legend>Modifier :</legend>
        <div class="control-group">
            <input type="hidden" name="idppe" value="<?php echo $resa -> idppe;?>"><br>
                <label class="control-label" for="lib">Libellé</label>
                    <div class="controls">
                        <input type="text" name="lib" Value="<?php echo $resa -> lib;?>" class="input-xlarge"><br>
                    </div>
                <label class="control-label" for="description">description</label>
                    <div class="controls">
                        <input type="text" name="description" Value="<?php echo $resa -> description;?>"><br>
                    </div>
                <label class="control-label" for="lienphoto1">Photo</label>
                    <div class="controls">
                        <img src="<?php echo $resa -> lienphoto1;?>" name="lienphoto1" class="image_petit" alt="image"><br><br>
                    </div>
                    <input type="file" name="lienphoto1"> <br>
                <label class="control-label" for="lienapllication">Lienapp</label>
                    <div class="controls">
                        <input type="text" name="lienapplication" value="<?php echo $resa -> lienapplication;?>"><br><br>
                    </div>
    <?php
    $SQL = "SELECT * FROM possede
            WHERE idppe = $id";
    $resultat = $conn->Query($SQL);
    $resultat->setFetchMode(PDO::FETCH_OBJ);
    while ($resa = $resultat->fetch ())
    {
    ?>
    <label>
        <input type="checkbox" name="check[]" value="<?php echo $resa -> idcompetence;?>"
        <?php
            if ($resa->ouinon==1)
            {
                echo 'checked';
            }
        ?>
        />
        <?php echo $resa -> idcompetence;?>
    </label>
    <?php
    }
    ?>
    <br>
                    <input type="submit" name="modifier" class="add" value="Modifier">
                </div>
            </fieldset>
            </form>
        </div>
    </div>
   <?php } ?>

    </body>
</html>


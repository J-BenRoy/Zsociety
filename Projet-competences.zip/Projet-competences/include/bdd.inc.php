<?php
    $host='localhost';
    $bdd='projetcompetence';
    $user='root';
    $pass='';
$conn=new PDO('mysql:host='.$host.';dbname='.$bdd,$user,$pass);
?>

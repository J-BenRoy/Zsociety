<?php
    include '../include/bdd.inc.php';    
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="IAMX, One Page Responsive HTML Resume Template">
  <meta name="keywords" content="onepage, resume, CV HTML template, personal Vcard, html resume, free resume template, free HTML template, free bootstrap template, personal portfolio, free html portfolio">
	<meta name="author" content="http://trendytheme.net/">

	<title>Benjamin Roy | Développeur Web</title>

  <!-- Web Fonts -->
  <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,500,700' rel='stylesheet' type='text/css'>
	<!-- Bootstrap core CSS -->
	<link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
	<!-- Font Awesome CSS -->
	<link href="assets/css/font-awesome.min.css" rel="stylesheet" media="screen">
	<!-- Animate css -->
  <link href="assets/css/animate.css" rel="stylesheet">
  <!-- Magnific css -->
	<link href="assets/css/magnific-popup.css" rel="stylesheet">
	<!-- Custom styles CSS -->
	<link href="assets/css/style.css" rel="stylesheet" media="screen">
  <!-- Responsive CSS -->
  <link href="assets/css/responsive.css" rel="stylesheet">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->

  <link rel="shortcut icon" href="assets/images/ico/favicon.png">
  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/ico/apple-touch-icon-144-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/ico/apple-touch-icon-114-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/ico/apple-touch-icon-72-precomposed.png">
  <link rel="apple-touch-icon-precomposed" href="assets/images/ico/apple-touch-icon-57-precomposed.png">

</head>

<body>
	<!-- Preloader -->
	<div id="tt-preloader">
		<div id="pre-status">
			<div class="preload-placeholder"></div>
		</div>
	</div>

	<!-- Home Section -->
	<section id="home" class="tt-fullHeight" data-stellar-vertical-offset="50" data-stellar-background-ratio="0.2">
		<div class="intro">
		
			<div class="intro-sub">Je suis Benjamin ROY</div>
			<h1>DEVELOPPEUR <span>WEB</span></h1>
			

      <div class="social-icons">
        <ul class="list-inline">
          <li><a href="https://www.facebook.com/benjam.roy"><i class="fa fa-facebook"></i></a></li>
          <li><a href="https://twitter.com/Graenir"><i class="fa fa-twitter"></i></a></li>
          <li><a href="https://www.linkedin.com/in/benjamin-roy-felicien-207755113?trk=nav_responsive_tab_profile"><i class="fa fa-linkedin"></i></a></li>
          <li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li>
          <li><a href="https://play.spotify.com/user/spotifydiscover/playlist/2FdPCdGu48kSbtpoMyx5pw"><i class="fa fa-spotify"></i></a></li>
        </ul>
      </div> <!-- /.social-icons -->
		</div>

		<div class="mouse-icon">
			<div class="wheel"></div>
		</div>
	</section><!-- End Home Section -->




	<!-- Navigation -->
	<header class="header">
		<nav class="navbar navbar-custom" role="navigation">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#custom-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
                    </button>
				</div>

				<div class="collapse navbar-collapse" id="custom-collapse">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="#home">Accueil</a></li>
						<li><a href="#about">A propos de moi</a></li>
						<li><a href="#resume">Resume</a></li>
						<li><a href="#skills">Compétences</a></li>
						<li><a href="#works">Projets</a></li>
            <li><a href="#contact">Contact</a></li>
					</ul>
				</div>
			</div><!-- .container -->
		</nav>
	</header><!-- End Navigation -->


    <!-- About Section -->
    <section id="about" class="about-section section-padding">
      <div class="container">
        <h2 class="section-title wow fadeInUp">A propos de moi</h2>

        <div class="row">
          

          <div class="col-md-4 col-md-push-8">
            <div class="biography">
              <div class="myphoto">
                <img src="assets/images/Snapchat-7165282956411488907.jpg" alt="">
              </div>
              <ul>
                <li><strong>Nom:</strong> Benjamin Roy</li>
                <li><strong>Date de naissance :</strong> 16 Novembre 1996</li>
                <li><strong>Addresse :</strong> 4 impasse des chênes, Brive-la-Gaillarde, France</li>
                <li><strong>Nationalité :</strong> Français</li>
                <li><strong>Téléphone :</strong> 06.49.72.94.34</li>
                <li><strong>Email:</strong> roybenjamin16@outlook.fr</li>
              </ul>
            </div>
          </div> <!-- col-md-4 -->
          <?php
                $SQL="SELECT * FROM presentation";
                $resultat=$conn->Query($SQL);
                $resultat->setFetchMode(PDO::FETCH_OBJ);
                $resa=$resultat->fetch();
            ?>
          <div class="col-md-8 col-md-pull-4">
            <div class="short-info wow fadeInUp">
              <h3>Présentation :</h3>
              <p><?php echo $resa -> presentation;?></p>
            </div>

            <div class="download-button">
              <a class="btn btn-info btn-lg" href="#contact"><i class="fa fa-paper-plane"></i>Send me message</a>
              <a class="btn btn-primary btn-lg" href="CV.pdf"><i class="fa fa-download"></i>download my cv</a>
            </div>
          </div>


        </div> <!-- /.row -->
      </div> <!-- /.container -->
    </section><!-- End About Section -->


    <!-- Facts Section -->
    <section id="facts" class="facts-section text-center" data-stellar-vertical-offset="50" data-stellar-background-ratio="0.2">
      <div class="tt-overlay-bg">
      </div>
    </section> <!-- End Facts Section -->


    <!-- Resume Section -->
    <section id="resume" class="resume-section section-padding">
        <div class="container">
            <h2 class="section-title wow fadeInUp">Resume</h2>
            <div class="row">
                <div class="col-md-12">
                    <div class="resume-title">
                        <h3>Education</h3>
                    </div>
                    <div class="resume">
                        <ul class="timeline">
                           <li class="timeline-inverted">
                                <div class="posted-date">
                                    <span class="month">2013-2014</span>
                                </div><!-- /posted-date -->

                                <div class="timeline-panel wow fadeInUp">
                                    <div class="timeline-content">
                                        <div class="timeline-heading">
                                            <h3>Brevet d'études professionelles SEN</h3>
                                            <span>à Cabanis, Brive-la-gaillarde, France</span>
                                        </div><!-- /timeline-heading -->

                                        <div class="timeline-body">
                                            <p>J'ai obtenu mon BEP <br>(Système électronique et numérique).</p>
                                        </div><!-- /timeline-body -->
                                    </div> <!-- /timeline-content -->
                                </div><!-- /timeline-panel -->
                            </li>
                            <li>
                                <div class="posted-date">
                                    <span class="month">2013-2015</span>
                                </div><!-- /posted-date -->

                                <div class="timeline-panel wow fadeInUp">
                                    <div class="timeline-content">
                                        <div class="timeline-heading">
                                            <h3>Baccalauréat professionnel SEN</h3>
                                            <span>à Cabanis, Brive-la-gaillarde, France</span>
                                        </div><!-- /timeline-heading -->

                                        <div class="timeline-body">
                                            <p>J'ai obtenu mon Baccalauréat avec mention Assez Bien <br>(Système électronique et numérique).</p>
                                        </div><!-- /timeline-body -->
                                    </div> <!-- /timeline-content -->
                                </div><!-- /timeline-panel -->
                            </li>
        
                            <li class="timeline-inverted">
                                <div class="posted-date">
                                    <span class="month">2015-20**</span>
                                </div><!-- /posted-date -->

                                <div class="timeline-panel wow fadeInUp">
                                    <div class="timeline-content">
                                        <div class="timeline-heading">
                                            <h3>BTS SIO</h3>
                                            <span>Developpement Web, Bahuet, Brive-la-gaillarge, France</span>
                                        </div><!-- /timeline-heading -->

                                        <div class="timeline-body">
                                            <p>L'objectif de ce BTS est de former l'élève à développer, à adapter et à maintenir des solutions applicatives.</p>
                                        </div><!-- /timeline-body -->
                                    </div> <!-- /timeline-content -->
                                </div> <!-- /timeline-panel -->
                            </li>
                            

                        </ul>
                    </div>
                </div>
            </div><!-- /row -->

            <div class="row">
                <div class="col-md-12">
                    <div class="resume-title">
                        <h3>Experience</h3>
                    </div>
                    <div class="resume">
                        <ul class="timeline">
                           <li class="timeline-">
                                <div class="posted-date">
                                    <span class="month">2013-2014</span>
                                </div><!-- /posted-date -->

                                <div class="timeline-panel wow fadeInUp">
                                    <div class="timeline-content">
                                        <div class="timeline-heading">
                                            <h3>Stage en entreprise lors de ma premiere année de BAC</h3>
                                            <span>à Micromal'1, Donzenac, France</span>
                                        </div><!-- /timeline-heading -->
                                    </div> <!-- /timeline-content -->
                                </div><!-- /timeline-panel -->
                            </li>
                            
                            <li class="timeline-inverted">
                                <div class="posted-date">
                                    <span class="month">2013-2014</span>
                                </div><!-- /posted-date -->

                                <div class="timeline-panel wow fadeInUp">
                                    <div class="timeline-content">
                                        <div class="timeline-heading">
                                            <h3>Stage en entreprise lors de ma seconde année de BAC</h3>
                                            <span>à Photonis, Brive-la-gaillarde, France</span>
                                        </div><!-- /timeline-heading -->
                                    </div> <!-- /timeline-content -->
                                </div><!-- /timeline-panel -->
                            </li>
                            
                            <li class="timeline-">
                                <div class="posted-date">
                                    <span class="month">2013-2014</span>
                                </div><!-- /posted-date -->

                                <div class="timeline-panel wow fadeInUp">
                                    <div class="timeline-content">
                                        <div class="timeline-heading">
                                            <h3>Stage en entreprise lors de ma troisième année de BAC</h3>
                                            <span>à C.O.A.E Brive, Brive-la-gaillarde, France</span>
                                        </div><!-- /timeline-heading -->
                                    </div> <!-- /timeline-content -->
                                </div><!-- /timeline-panel -->
                            </li>
                            <li class="timeline-inverted">
                                <div class="posted-date">
                                  <span class="month">2016-2016</span>
                                </div><!-- /posted-date -->

                                <div class="timeline-panel wow fadeInUp">
                                    <div class="timeline-content">
                                        <div class="timeline-heading">
                                            <h3>Stage de BTS</h3>
                                            <span>ConsonaceWeb, Brive-la-gaillarde</span>
                                        </div><!-- /timeline-heading -->

                                        <div class="timeline-body">
                                            <p></p>
                                        </div><!-- /timeline-body -->
                                    </div> <!-- /timeline-content -->
                                </div> <!-- /timeline-panel -->
                            </li>

                        </ul>
                    </div>
                </div>
            </div><!-- /row -->
        </div><!-- /.container -->
    </section><!-- End Resume Section -->


    <!-- Skills Section -->
    <section id="skills" class="skills-section section-padding">
      <div class="container">
        <h2 class="section-title wow fadeInUp">Compétences</h2>
            <?php
                $SQL="SELECT * FROM competence";
                $resultat=$conn->Query($SQL);
                $resultat->setFetchMode(PDO::FETCH_OBJ);
                $resa=$resultat->fetch();
            ?>
            <div class="skill-chart text-center">
                <div class="col-xs-12 col-sm-4 col-md-4">
                    <div class="chart" data-percent="<?php echo $resa -> css;?>" data-color="e74c3c">
                        <span class="percent"></span>
                        <div class="chart-text">
                            <span>css</span>
                        </div>
                    </div>
                </div>
            <div class="col-xs-12 col-sm-4 col-md-4">
              <div class="chart" data-percent="<?php echo $resa -> html;?>" data-color="2ecc71">
                    <span class="percent"></span>
                    <div class="chart-text">
                      <span>html</span>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-4 col-md-4">
              <div class="chart" data-percent="<?php echo $resa -> php;?>" data-color="3498db">
                    <span class="percent"></span>
                    <div class="chart-text">
                      <span>php</span> 
                    </div>
                </div>
            </div>
          </div>
        </div>
          <?php
                $SQL="SELECT * FROM language";
                $resultat=$conn->Query($SQL);
                $resultat->setFetchMode(PDO::FETCH_OBJ);
                $resa=$resultat->fetch();
          ?>
        <div class="container">   
        <div class="row more-skill text-center">
          <br><h3>Languages</h3><br><br>
            <div class="row">
          <div class="col-md-12">
            <div class="skill-progress">
              <div class="skill-title"><h3>Français</h3></div> 
              <div class="progress">
                <div class="progress-bar six-sec-ease-in-out" role="progressbar" aria-valuenow="<?php echo $resa -> francais;?>" aria-valuemin="0" aria-valuemax="100" ><span><?php echo $resa -> francais;?>%</span>
                </div>
              </div><!-- /.progress -->
            </div><!-- /.skill-progress -->

            <div class="skill-progress">
              <div class="skill-title"><h3>Anglais</h3></div> 
              <div class="progress">
                <div class="progress-bar six-sec-ease-in-out" role="progressbar" aria-valuenow="<?php echo $resa -> anglais;?>" aria-valuemin="0" aria-valuemax="100" ><span><?php echo $resa -> anglais;?>%</span>
                </div>
              </div><!-- /.progress -->
            </div><!-- /.skill-progress -->
          </div><!-- /.col-md-6 -->
        </div><!-- /.row -->
            
        </div>

      </div><!-- /.container -->
    </section><!-- End Skills Section -->


    <!-- Works Section -->
    <section id="works" class="works-section section-padding">
      <div class="container">
        <h2 class="section-title wow fadeInUp">Works</h2>

        <ul class="list-inline" id="filter">
            <li><a class="active" data-group="all">All</a></li>
            <li><a data-group="design">Design</a></li>
            <li><a data-group="web">Web</a></li>
            <li><a data-group="interface">Interface</a></li>
            <li><a data-group="identety">Identity</a></li>
        </ul>

        <div class="row">
          <div id="grid">
            <div class="portfolio-item col-xs-12 col-sm-4 col-md-3" data-groups='["all", "identety", "interface", "web"]'>
              <div class="portfolio-bg">
                <div class="portfolio">
                  <div class="tt-overlay"></div>
                  <div class="links">
                    <a class="image-link" href="assets/images/works/Comingsoon1.png"><i class="fa fa-search-plus"></i></a>
                    <a href="#"><i class="fa fa-link"></i></a>                          
                  </div><!-- /.links -->
                  <img src="assets/images/works/Comingsoon1.png" alt="image"> 
                  <div class="portfolio-info">
                    <h3>En attente.</h3>
                  </div><!-- /.portfolio-info -->
                </div><!-- /.portfolio -->
              </div><!-- /.portfolio-bg -->
            </div><!-- /.portfolio-item -->
            </div>
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- End Works Section -->


    <!-- Facts Section -->
    <section id="facts" class="facts-section text-center" data-stellar-vertical-offset="50" data-stellar-background-ratio="0.2">
      <div class="tt-overlay-bg">
      </div>
    </section> <!-- End Facts Section -->



    <!-- Contact Section -->
    <section id="contact" class="contact-section section-padding">
      <div class="container">
        <h2 class="section-title wow fadeInUp">Me contacter</h2>

        <div class="row">
          <div class="col-md-6">
            <div class="contact-form">
              <strong>Envoyer moi un message</strong>
              <form name="contact-form" id="contactForm" action="sendemail.php" method="POST">

                <div class="form-group">
                  <label for="name">Nom</label>
                  <input type="text" name="name" class="form-control" id="name" required="">
                </div>

                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="email" name="email" class="form-control" id="email" required="">
                </div>

                <div class="form-group">
                  <label for="subject">Sujet</label>
                  <input type="text" name="subject" class="form-control" id="subject">
                </div>

                <div class="form-group">
                  <label for="message">Message</label>
                  <textarea name="message" class="form-control" id="message" rows="5" required=""></textarea>
                </div>

                <button type="submit" name="submit" class="btn btn-primary">Envoyer</button>
              </form>
            </div><!-- /.contact-form -->
          </div><!-- /.col-md-6 -->

          <div class="col-md-6">
            <div class="row center-xs">
              <div class="col-sm-6">
                <i class="fa fa-map-marker"></i>
                <address>
                  <strong>Adresse</strong>
                  4 impasse des chênes,<br>
                  Brive-la-gaillarde, France<br>
                </address>
              </div>

              <div class="col-sm-6">
                <i class="fa fa-mobile"></i>
                <div class="contact-number">
                  <strong>Numero de téléphone</strong>
                  05.87.49.46.07<br>
                  06.49.72.94.34
                </div>
              </div>
            </div>

          <div class="row">
            <div class="col-sm-12">
              <div class="location-map">
                <div id="mapCanvas" class="map-canvas"></div>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d45024.83655792147!2d1.4793082164407878!3d45.14553723690998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47f8bd494a823efb%3A0x405d39260ee76f0!2sBrive-la-Gaillarde!5e0!3m2!1sfr!2sfr!4v1461602917794" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
              </div>
            </div>
          </div>

          </div>
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- End Contact Section -->


	<!-- Footer Section -->
    <footer class="footer-wrapper">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="copyright text-center">
              <p>Propulsé par Benjamin Roy. All rights reserved.</p>
            </div>
          </div>
        </div>
      </div>
    </footer><!-- End Footer Section -->


	<!-- Scroll-up -->
	<div class="scroll-up">
		<a href="#home"><i class="fa fa-angle-up"></i></a>
	</div>

	<!-- Javascript files -->
	<script src="assets/js/jquery.js"></script>
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery.stellar.min.js"></script>
	<script src="assets/js/jquery.sticky.js"></script>
  <script src="assets/js/smoothscroll.js"></script>
	<script src="assets/js/wow.min.js"></script>
  <script src="assets/js/jquery.countTo.js"></script>
  <script src="assets/js/jquery.inview.min.js"></script> 
  <script src="assets/js/jquery.easypiechart.js"></script>
  <script src="assets/js/jquery.shuffle.min.js"></script>
  <script src="assets/js/jquery.magnific-popup.min.js"></script>
  <script src="http://a.vimeocdn.com/js/froogaloop2.min.js"></script>
  <script src="assets/js/jquery.fitvids.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>
  <script src="assets/js/scripts.js"></script>
</body>
</html>
<?php
    $host='localhost';
    $bdd='test';
    $user='root';
    $pass='';
$conn=new PDO('mysql:host='.$host.';dbname='.$bdd,$user,$pass);
?>

<?php
include '../include/bdd.inc.php';
$id=$_POST['id'];
$lib=$_POST['lib'];
$des=addslashes($_POST['description']);
$dir="Document/";

$tmp1=$_FILES['photo1']['tmp_name'];
$name1=$_FILES['photo1']['name'];
$chemin1 = $dir.$name1;
move_uploaded_file($tmp1,$chemin1);
if($chemin1!='Documents/')
	{
		$SQL="UPDATE ppe SET photo1='$chemin1' where id='$id'";
		$conn->query($SQL);
	}
$tmp2=$_FILES['photo2']['tmp_name'];
$name2=$_FILES['photo2']['name'];
$chemin2 = $dir.$name2;
move_uploaded_file($tmp2,$chemin2);
if($chemin2!='Documents/')
	{
		$SQL="UPDATE ppe SET photo1='$chemin2' where id='$id'";
		$conn->query($SQL);
	}
$tmp3=$_FILES['photo3']['tmp_name'];
$name3=$_FILES['photo3']['name'];
$chemin3 = $dir.$name3;
move_uploaded_file($tmp3,$chemin3);
if($chemin3!='Documents/')
	{
		$SQL="UPDATE ppe SET photo1='$chemin3' where id='$id'";
		$conn->query($SQL);
	}

$SQL="UPDATE ppe
SET lib='$lib',photo1='$chemin1',photo2='$chemin2',photo3='$chemin3',descriptif='$des' where id='$id'";
$conn->query($SQL);
Header('Location:include.php');
?>

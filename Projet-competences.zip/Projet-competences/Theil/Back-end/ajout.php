<?php
    include '../include/bdd.inc.php';
    $idppe=$_POST['liste'];
    $SQL="SELECT * FROM ppe WHERE id='$idppe'";
    $res=$conn->query($SQL);
    $res->setFetchMode(PDO::FETCH_OBJ);
    $resultat=$res->fetch()
?>
<form method="post" action="ajout_valider.php">
    <input type="text" name="lib" value="<?php echo $resultat -> lib ?>">
    <input type="text" name="photo1" value="<?php echo $resultat -> photo1 ?>">
    <input type="text" name="photo2" value="<?php echo $resultat -> photo2 ?>">
    <input type="text" name="photo3" value="<?php echo $resultat -> photo3 ?>">
    <input type="text" name="descriptif" value="<?php echo $resultat -> descriptif ?>">
    <input type="hidden" name="id" value="<?php echo $resultat -> id ?>">
    <input type="submit" name="Valider">
</form>

<?php
include '../include/bdd.inc.php';
$fr=$_POST['francais'];
$ang=$_POST['anglais'];

$SQL="UPDATE language
SET francais='$fr',anglais='$ang'";
$conn->query($SQL);
Header('Location:portfolio.php');
?>
<?php
    include '../include/bdd.inc.php';
    $idppe=$_POST['liste'];
    $SQL="SELECT * FROM ppe WHERE id='$idppe'";
    $res=$conn->query($SQL);
    $res->setFetchMode(PDO::FETCH_OBJ);
    $resultat=$res->fetch()
?>
<form method="post" action="modification_valider.php" enctype="multipart/form-data">
    <input type="text" name="lib" value="<?php echo $resultat -> lib ?>">
    <input type="text" name="id" value="<?php echo $resultat -> id ?>">
    <input type="text" name="description">
    <input type="file" name="photo1">
    <input type="file" name="photo2">
    <input type="file" name="photo3">
    <input type="submit" name="Valider">
</form>

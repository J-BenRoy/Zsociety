<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Document</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/back.css" rel="stylesheet">
    </head>
    <body>
        <div class="container">
            <nav class="navbar navbar-inverse">
                <div class="container-fluid">
                    <ul class="nav navbar-nav">
                        <li> <a href="include.php">Accueil</a> </li>
                        <li class="active"> <a href="portfolio.php">Portfolio</a> </li>
                    </ul>
                </div>
            </nav>
        </div>
    <?php
        include '../include/bdd.inc.php';
        $SQL="SELECT * FROM competence";
        $resultat=$conn->Query($SQL);
        $resultat->setFetchMode(PDO::FETCH_OBJ);
        $resa=$resultat->fetch();
    ?>
        <div class="container">
            <div class="col-lg-3 col-lg-offset-3">
                <form method="post" action="competence.php">
                    <legend>Modifier les compétences :</legend>
                        <input type="text" name="php" placeholder="php : <?php echo $resa -> php;?>">
                        <input type="text" name="css" placeholder="css : <?php echo $resa -> css;?>">
                        <input type="text" name="html" placeholder="html : <?php echo $resa -> html;?>">
                        <input type="submit" name="ajouter">
                </form>
            </div>
        </div>
        
    <?php
        include '../include/bdd.inc.php';
        $SQL="SELECT * FROM language";
        $resultat=$conn->Query($SQL);
        $resultat->setFetchMode(PDO::FETCH_OBJ);
        $resa=$resultat->fetch();
    ?>
        <div class="container">
            <div class="col-lg-3 col-lg-offset-3">
                <form method="post" action="language.php">
                    <legend>Modifier les languages :</legend>
                        <input type="text" name="francais" placeholder="Français : <?php echo $resa -> francais;?>">
                        <input type="text" name="anglais" placeholder="Anglais : <?php echo $resa -> anglais;?>">
                        <input type="submit" name="ajouter">
                </form>
            </div>
        </div>
    <?php
        include '../include/bdd.inc.php';
        $SQL="SELECT * FROM presentation";
        $resultat=$conn->Query($SQL);
        $resultat->setFetchMode(PDO::FETCH_OBJ);
        $resa=$resultat->fetch();
    ?>
        <div class="container">
            <div class="col-lg-3 col-lg-offset-3">
                <form method="post" action="presentation.php">
                    <legend>Modifier la présentation :</legend>
                    <textarea rows="10" cols="80" type="text" name="presentation" placeholder="Actuellement : <?php echo $resa -> presentation;?>"></textarea>
                        <input type="submit" name="ajouter">
                </form>
            </div>
        </div>























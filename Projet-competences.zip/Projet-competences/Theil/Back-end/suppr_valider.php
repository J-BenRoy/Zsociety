<?php
    include '../include/bdd.inc.php';
    $id = $_POST['id'];
    $SQL="DELETE FROM PPE
          WHERE id ='$id'";
    $resa=$conn->Query($SQL);
Header('Location: include.php');
?>

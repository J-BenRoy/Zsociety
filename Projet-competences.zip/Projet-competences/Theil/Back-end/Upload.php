<?php
if(isset($_POST['ajouter']))
{
    include '../include/bdd.inc.php';
    $dir='Document/';
    $tmp1=$_FILES['photo1']['tmp_name'];
    //var_dump($tmp1);
    $name1=$_FILES['photo1']['name'];
    move_uploaded_file($tmp1,$dir.$name1);
    $tmp2=$_FILES['photo2']['tmp_name'];
    //var_dump($tmp2);
    $name2=$_FILES['photo2']['name'];
    move_uploaded_file($tmp2,$dir.$name2);
    $tmp3=$_FILES['photo3']['tmp_name'];
    //var_dump($tmp3);
    $name3=$_FILES['photo3']['name'];
    move_uploaded_file($tmp3,$dir.$name3);
    $lib = $_POST['lib'];
    $photo1 = $dir.$name1;
    $photo2 = $dir.$name2;
    $photo3 = $dir.$name3;
    $descriptif = $_POST['descriptif'];
    $SQL="INSERT INTO PPE(id,lib,photo1,photo2,photo3,descriptif)
    VALUES('','$lib','$photo1','$photo2','$photo3','$descriptif')";
    $resa=$conn->Query($SQL);
    //Header('Location:Validation.html');
}
?>

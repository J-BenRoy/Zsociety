<?php
include '../include/bdd.inc.php';
$pres=addslashes($_POST['presentation']);

$SQL="UPDATE presentation
SET presentation='$pres'";
$conn->query($SQL);
Header('Location:portfolio.php');
?>
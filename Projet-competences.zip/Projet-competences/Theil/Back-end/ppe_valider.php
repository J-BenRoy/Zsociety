<?php
    include '../include/bdd.inc.php';
    $id = $_POST['id'];
    $lib = $_POST['lib'];
    $SQL="UPDATE PPE
          SET lib ='$lib'
          WHERE id ='$id'";
    $resa=$conn->Query($SQL);
Header('Location: include.php');
?>

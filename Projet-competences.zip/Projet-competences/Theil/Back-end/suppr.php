<?php
    include '../include/bdd.inc.php';
    $idppe=$_POST['liste'];
    $SQL="SELECT * FROM ppe WHERE id='$idppe'";
    $res=$conn->query($SQL);
    $res->setFetchMode(PDO::FETCH_OBJ);
    $resultat=$res->fetch()
?>
<form method="post" action="suppr_valider.php">
       <?php echo $resultat -> lib ?>
    <input type="hidden" name="id" value="<?php echo $resultat -> id ?>">
    <input type="submit" name="Valider">
</form>

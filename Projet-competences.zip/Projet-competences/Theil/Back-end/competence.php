<?php
include '../include/bdd.inc.php';
$css=$_POST['css'];
$html=$_POST['html'];
$php=$_POST['php'];

$SQL="UPDATE competence
SET css='$css',html='$html',php='$php'";
$conn->query($SQL);
Header('Location:include.php');
?>
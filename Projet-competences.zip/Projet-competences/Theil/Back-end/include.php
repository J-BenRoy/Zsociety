<?php
    include '../include/bdd.inc.php';
    $resa=$conn->query ("SELECT * FROM ppe");
    $resa->setFetchMode(PDO::FETCH_OBJ);
?>
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Document</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/back.css" rel="stylesheet">
    </head>
    <body>
        <div class="container">
            <nav class="navbar navbar-inverse">
                <div class="container-fluid">
                    <ul class="nav navbar-nav">
                        <li class="active"> <a href="#">Accueil</a> </li>
                        <li> <a href="portfolio.php">Portfolio</a> </li>
                    </ul>
                </div>
            </nav>
        </div>
       <div class="container">
           <div class="col-lg-3  col-lg-offset-3">
              <form class="form-horizontal" method="post" name="liste" action="ppe.php">
                <fieldset>
            <legend>Update :</legend>
        <select name="liste">
            <?php
                While ($resultat = $resa -> Fetch())
                {
            ?>
                <option value="<?php echo $resultat -> id ?>"> <?php echo $resultat -> lib?></option>
            <?php
                }
            ?>
        </select>

        <input type="submit" name="choix">
            </fieldset>

        </form>

           </div>
       </div>
        <br>

        <?php
            $resa=$conn->query ("SELECT * FROM ppe");
            $resa->setFetchMode(PDO::FETCH_OBJ);
        ?>
        <div class="container">
           <div class="col-lg-3 col-lg-offset-3">
        <form method="post" name="liste" action="suppr.php">
           <legend>Supprimer une ligne :</legend>
        <select name="liste">
            <?php
                While ($resultat = $resa -> Fetch())
                    {
            ?>
            <option value="<?php echo $resultat -> id ?>"> <?php echo $resultat -> lib?></option>
                <?php
                    }
                ?>
        </select>

        <input type="submit" name="choix">

        </form>
            </div>
        </div>
        <br>

        <div class="container">
           <div class="col-lg-3 col-lg-offset-3">
        <form method="post" enctype="multipart/form-data" action="upload.php">
           <legend>Ajouter une ligne :</legend>
            <input type="text" name="lib" placeholder="libelle">
            <input type="text" name="descriptif" placeholder="description">
            <input type="file" name="photo1">
            <input type="file" name="photo2">
            <input type="file" name="photo3">
            <br>
            <input type="submit" name="ajouter" class="pull-right" value="ajouter">
        </form>
            </div>
        </div>
        <br>
        <?php
            $resa=$conn->query ("SELECT * FROM ppe");
            $resa->setFetchMode(PDO::FETCH_OBJ);
        ?>
          <div class="container">
           <div class="col-lg-3 col-lg-offset-3">
        <form method="post" name="liste" action="modification.php" enctype="multipart/form-data">
           <legend>Modifier une ligne :</legend>
        <select name="liste">
            <?php
                While ($resultat = $resa -> Fetch())
                    {
            ?>
            <option value="<?php echo $resultat -> id ?>"> <?php echo $resultat -> lib?></option>
                <?php
                    }
                ?>
            </select>
            <input type="submit" name="ajouter" value="Modifier">
        </form>
              </div>
        </div>
    </body>
</html>

<?php

    include '../include/bdd.inc.php';
//Vérifie et redirige vers Administrateur.php
    if(isset($_POST['Identifiant']) && isset($_POST['Motdepasse']))
    {
        $req = $conn->prepare("SELECT * FROM administrateur WHERE Identifiant = ? AND Motdepasse = ?");
        $req->execute(array($_POST['Identifiant'], $_POST['Motdepasse']));
        $data = $req->fetch();
        var_dump($data);
         if($data)
         {
              header('Location:include.php');
         }
         else
         {
              header('Location:index.html');
         }
    }
    else
    {
        header('Location:index.html');
    }
?>

<?php
    include '../include/bdd.inc.php';
    $SQL="SELECT * FROM competence";
                $resultat=$conn->Query($SQL);
                $resultat->setFetchMode(PDO::FETCH_OBJ);
                $resa=$resultat->fetch();
?>
<div class="container">
           <div class="col-lg-3 col-lg-offset-3">
        <form method="post" action="competence.php">
           <legend>Modifier une ligne :</legend>
            <input type="text" name="php" placeholder="php : <?php echo $resa -> php;?>">
            <input type="text" name="css" placeholder="css : <?php echo $resa -> css;?>">
            <input type="text" name="html" placeholder="html : <?php echo $resa -> html;?>">
            <input type="submit" name="ajouter">
        </form>
            </div>
        </div>